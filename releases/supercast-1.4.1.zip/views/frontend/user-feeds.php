<?php use Supercast_Utilities as Utils;

foreach ($subscriptions as $index => $subscription) :
  $feed_url = $subscription['feed_url'];
  $feed_id = $subscription['id'];

  if ($options['titles'] != 'false') : ?>
    <p class="supercast-feed-title">
      <?php echo $subscription['title']; ?>
    </p>
  <?php endif;

  if (in_array($options['type'], ['urls', 'all', null])) : ?>
    <p class="supercast-field-container inline supercast-feed-url">
      <input type="text" class="supercast-feed-url-raw" id="supercast-feed-copy-id-<?php echo $feed_id; ?>" value="<?php echo $feed_url; ?>" readonly />
      <button class="supercast-feed-url-button" data-clipboard-target="#supercast-feed-copy-id-<?php echo $feed_id; ?>">Copy</button>
    </p>
  <?php endif;

  if (in_array($options['type'], ['deeplinks', 'all', null])) : ?>
    <div class="supercast-feed-deeplinks">
      <ul>
        <?php foreach ($link_providers as $index => $name) :
          $id = str_replace(' ', '-', strtolower($name));
          $url = Utils::parse_provider_link(Utils::FEED_LINK_PROVIDERS[$name], $feed_url);
          $unique_id = $id . '-' . $feed_id;
          ?>
            <li id="deeplink-<?php echo $unique_id; ?>">
              <a href="<?php echo $url ?>" target="_blank">
                <?php if ($display_icons) :
                  $image_regular_path = $image_base_path . $id . '.png';
                  $image_retina_path = $image_base_path . $id . '@2x' . '.png';
                ?>
                  <img
                    src="<?php echo $image_regular_path; ?>"
                    srcset="<?php echo $image_regular_path; ?> 1x, <?php echo $image_retina_path; ?> 2x"
                    alt="<?php echo $name; ?>" />
                <?php endif; ?>
                <?php echo $name; ?>
              </a>
            </li>
          <?php
        endforeach; ?>
      </ul>
    </div>
  <?php endif;

  if (!array_key_exists('hide_powered_by', $options)) : ?>
    <p class="supercast-powered-by" style='font-size: 14px; color: #666;  vertical-align: middle;'>
      Powered by  <a href='https://supercast.com' target="_blank"><img
                    src="/wp-content/plugins/supercast/assets/supercast_logo.svg"
                    alt="Supercast"
                    style='height: 18px; vertical-align: middle; padding-left: 3px; -webkit-filter: grayscale(1);' /></a>
    </p>
  <?php endif;
endforeach; ?>
