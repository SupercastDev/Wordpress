<form class="supercast-field-container supercast-ask-question" data-channel="<?php echo $channel; ?>">
  <input class="supercast-question-title" type="text" placeholder="Question title" />
  <textarea class="supercast-question-body" placeholder="What’s your question?"></textarea>
  <button class="supercast-question-submit">Submit</button>
</form>
