// Allow a NodeList to be iterated on (forEach, map, filter, etc)
NodeList.prototype.__proto__ = Array.prototype;

var Supercast = {}

Supercast.Options = {
  init: function () {
    this.codeEditorInited = false;
    this.form = document.querySelector('.options-form');

    this.initTabs();
    this.initApiSync();
    this.initSubscriptionPairing();
    this.initMemberfulCode();
    this.initToggleable();
    this.initResetPlugin();

    this.memberUpdateEvent = new Event('memberful-update');
  },

  // Tabbed settings

  initTabs: function () {
    var currentTab = null;
    var currentTabField = this.form.querySelector('[name="current_tab"]');

    // This is both tab links and containers
    var tabItems = document.querySelectorAll('[data-tab]');

    window.addEventListener('hashchange', function (event) {
      var hash = window.location.hash;
      if (hash.indexOf('#tab-') < 0) { return }

      var newTab = hash.slice(5, hash.length);

      if (newTab === currentTab) { return; }

      tabItems.filter(function (el) {
        return el.dataset.tab === currentTab;
      }).forEach(function (el) {
        el.classList.remove('active');
      });

      tabItems.filter(function (el) {
        return el.dataset.tab === newTab;
      }).forEach(function (el) {
        el.classList.add('active');
      });

      currentTab = newTab;
      currentTabField.value = newTab;

      if (newTab === 'advanced') {
        this.initCodeEditor();
      }
    }.bind(this));

    if (!window.location.hash.length) {
      window.location.hash = '#tab-general';
    }

    window.dispatchEvent(new Event('hashchange'));
  },

  // API syncing

  initApiSync: function () {
    this.syncing = false;

    this.inputSubscribableSyncedAt = this.form.querySelector('.subscribable-synced-at');
    this.inputSubscribableType = this.form.querySelector('.subscribable-type');

    this.tokenField = document.querySelector('.access-token-field');
    this.syncButton = document.querySelector('.access-connection input');
    this.syncInfo = document.querySelector('.access-connection .description');

    this.onTokenFieldChange();
    this.tokenField.addEventListener('change', this.onTokenFieldChange.bind(this));
    this.tokenField.addEventListener('keyup', this.onTokenFieldChange.bind(this));
    this.syncButton.addEventListener('click', this.onSyncButtonClicked.bind(this));

    this.setLastSyncedLabel();
  },

  onTokenFieldChange: function () {
    if (this.syncing) { return; }

    if (this.tokenField.value.trim().length) {
      this.syncButton.removeAttribute('disabled');
      this.syncInfo.textContent = 'You’re ready to fetch from Supercast.';
    } else {
      this.syncButton.setAttribute('disabled', 'disabled');
      this.syncInfo.textContent = this.syncInfo.dataset.default;
    }
  },

  onSyncButtonClicked: function () {
    if (this.syncing || this.syncButton.hasAttribute('disabled')) { return; }

    this.syncing = true;
    this.syncButton.setAttribute('disabled', 'disabled');
    this.syncInfo.textContent = 'Retrieving from Supercast...';

    fetch(this.syncButton.dataset.url, {
      headers: { 'Authorization': 'Bearer ' + this.tokenField.value.trim() }
    }).then(function (response) {
      if (response.status !== 200) {
        return this.setErroredLabel();
      }

      response.json().then(this.onSyncData.bind(this));
    }.bind(this)).catch(this.setErroredLabel.bind(this));
  },

  onSyncData: function (data) {
    this.syncing = false;
    this.syncButton.removeAttribute('disabled');

    this.inputSubscribableSyncedAt.value = (new Date()).getTime();
    this.inputSubscribableType.value = data.subscribable_type;

    // Remove the old plans so we can add the new ones
    var existingPlans = this.form.querySelectorAll('.subscribable-plan-input');
    [].forEach.call(existingPlans, function (input) {
      input.parentNode.removeChild(input);
    }.bind(this));

    var channels = [];
    var networks = [];

    if (data.subscribable_type === 'channel') {
      channels = [data];
    } else if (data.subscribable_type === 'network') {
      channels = data.channels;
      networks = data.network_bundles;

      networks = networks.map(function (network) {
        network.subdomain = data.subdomain;
        return network;
      });
    }

    var formattedChannelPlans = this.generatePlanInputs(channels, 'channel');
    var formattedNetworksPlans = this.generatePlanInputs(networks, 'network', channels.length);

    window.scPlanSets = formattedChannelPlans.concat(formattedNetworksPlans);

    if (this.memberUpdateEvent) {
      document.dispatchEvent(this.memberUpdateEvent);
    }
    this.setLastSyncedLabel();
    this.form.submit();
  },

  generatePlanInputs: function (plans, type, offset) {
    offset = offset || 0;
    var formattedPlans = [];

    plans.forEach(function (plan, index) {
      var inputIndex = index + offset;

      this.form.insertAdjacentHTML('beforeend', '<input type="hidden" name="subscribable_plans[' + inputIndex + '][name]" class="subscribable-plan-input" value="' + (plan.title || plan.name) + '">');
      this.form.insertAdjacentHTML('beforeend', '<input type="hidden" name="subscribable_plans[' + inputIndex + '][id]" class="subscribable-plan-input" value="' + plan.id + '">');
      this.form.insertAdjacentHTML('beforeend', '<input type="hidden" name="subscribable_plans[' + inputIndex + '][type]" class="subscribable-plan-input" value="' + type + '">');
      this.form.insertAdjacentHTML('beforeend', '<input type="hidden" name="subscribable_plans[' + inputIndex + '][subdomain]" class="subscribable-plan-input" value="' + plan.subdomain + '">');

      formattedPlans.push({
        name: (plan.title || plan.name),
        id: plan.id,
        type: type,
        subdoman: plan.subdomain
      });
    }.bind(this));

    return formattedPlans;
  },

  setErroredLabel: function () {
    this.syncing = false;
    this.syncButton.removeAttribute('disabled');
    this.syncInfo.textContent = 'Sorry, something went wrong. Try again.';
  },

  setLastSyncedLabel: function () {
    if (!this.inputSubscribableSyncedAt.value.length) { return; }

    var date = new Date(parseInt(this.inputSubscribableSyncedAt.value));
    var message = 'Last fetched ' + this.timeAgo(date) + ' ago';
    this.syncInfo.textContent = message;
  },

  // Subscription pairing

  initSubscriptionPairing: function () {
    this.planSelect = this.form.querySelector('.subscription-pair-select select');
    this.planChoose = this.form.querySelector('.subscription-pair-select input[type=button]');
    this.pairContainers = this.form.querySelector('.subscription-pair-items');

    this.pairContainers.addEventListener('click', this.onPairContainerClick.bind(this));

    if (this.planChoose == null) {
      this.pairContainers.style.display = 'none';
    } else {
      this.planChoose.addEventListener('click', this.onSubscriptionPlanChosen.bind(this));
    }
  },

  onPairContainerClick: function (event) {
    var clicked = event.target;

    if (clicked.classList.contains('notice-dismiss')) {
      var item = clicked.closest('.subscription-pair-item');
      this.planSelect.insertAdjacentHTML('beforeend', '<option value="' + item.dataset.id + '">' + item.dataset.name + '</option>');
      item.parentNode.removeChild(item);
      document.dispatchEvent(this.memberUpdateEvent);
    }
  },

  onSubscriptionPlanChosen: function () {
    var selectedOption = this.planSelect.options[this.planSelect.selectedIndex];

    if (selectedOption.disabled) { return; }

    var removeButton = '<button type="button" class="notice-dismiss"></button>';
    var pairingTitle = '<p class="title">' + removeButton + selectedOption.textContent + '<span>(' + selectedOption.value + ')</span></p>';
    var titleInput = '<input type="hidden" name="subscription_pairs[' + selectedOption.value + '][name]" value="' + selectedOption.textContent + '">';
    var pairingOptions = '<div class="options">' + this.generatePairingRadios(selectedOption.value) + '</div>';
    var pairingContainer = '<div class="subscription-pair-item" data-id="' + selectedOption.value + '" data-name="' + selectedOption.textContent + '">' + pairingTitle + titleInput + pairingOptions + '</div>'
    this.pairContainers.insertAdjacentHTML('beforeend', pairingContainer);

    selectedOption.parentNode.removeChild(selectedOption);
    this.planSelect.selectedIndex = 0;
    document.dispatchEvent(this.memberUpdateEvent);
  },

  generatePairingRadios: function (providerPlanId) {
    var radios = '';

    window.scPlanSets.forEach(function (planSet) {
      var input = '<input type="radio" name="subscription_pairs[' + providerPlanId + '][id]" value="' + planSet.type + '_' + planSet.id + '">';
      radios = radios + '<label>' + input + '<span>' + planSet.type + '</span>' + planSet.name + '</label>';
    });

    return radios;
  },

  // Memberful webhook URL

  initMemberfulCode: function () {
    this.memberfulUrl = this.form.querySelector('.memberful-url code');

    if (this.memberfulUrl == null) { return; }

    var tokenField = document.querySelector('#access_token');
    tokenField.addEventListener('change', this.onMemberfulDependentInputChanged.bind(this));
    tokenField.addEventListener('keyup', this.onMemberfulDependentInputChanged.bind(this));
    this.pairContainers.addEventListener('change', this.onMemberfulDependentInputChanged.bind(this));
    document.addEventListener('memberful-update', this.onMemberfulDependentInputChanged.bind(this));
  },

  onMemberfulDependentInputChanged: function () {
    this.memberfulUrl.innerHTML = 'Please save your changes to get an updated URL.';

    var parent = this.memberfulUrl.parentNode;
    parent.classList.add('updated-flash');

    setTimeout(function () {
      parent.classList.remove('updated-flash');
    }, 700);
  },

  // Toggle sidebar accordions

  initToggleable: function () {
    var toggles = document.querySelectorAll('.toggle-header');

    [].forEach.call(toggles, function (toggle, index) {
      var container = toggle.closest('.toggle-section');

      toggle.addEventListener('click', function () {
        container.classList.toggle('active');
      });

      if (index == 0) {
        container.classList.add('active');
      }
    });
  },

  // Set up textarea syntax highlighting

  initCodeEditor: function () {
    if (this.codeEditorInited) { return; }

    var codeTextArea = this.form.querySelector('#shortcode_css');

    CodeMirror.fromTextArea(codeTextArea, {
      mode: 'css',
      tabSize: 2
    });

    this.codeEditorInited = true;
  },

  // Trigger plugin settings reset

  initResetPlugin: function () {
    var button = document.querySelector('.reset-button');

    button.addEventListener('click', function (event) {
      if (confirm('Are you sure you want to reset the plugin settings? This CANNOT be undone.')) {
        document.querySelector('.reset-form').submit();
      } else {
        event.preventDefault();
      }
    })
  },

  // Utility

  timeAgo: function (date) {
    var seconds = Math.floor((new Date() - date) / 1000);

    var interval = Math.floor(seconds / 31536000);
    if (interval > 1) { return interval + ' years'; }

    interval = Math.floor(seconds / 2592000);
    if (interval > 1) { return interval + ' months'; }

    interval = Math.floor(seconds / 86400);
    if (interval > 1) { return interval + ' days'; }

    interval = Math.floor(seconds / 3600);
    if (interval > 1) { return interval + ' hours'; }

    interval = Math.floor(seconds / 60);
    if (interval > 1) { return interval + ' minutes'; }

    return Math.floor(seconds) + ' seconds';
  }
}

document.addEventListener(
  'DOMContentLoaded',
  Supercast.Options.init.bind(Supercast.Options)
);
