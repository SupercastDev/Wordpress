<?php

if (!defined('ABSPATH')) { die('Access denied'); }

use Supercast_Utilities as Utils;

class Supercast_MembershipPlugin_Base {
  public const REQUIRED_PROPERTIES = [
    'name',
    'webhook_endpoint',
    'website_url',
    'support_url'
  ];

  public const REQUIRED_BASE_METHODS = [
    'feed_access_items'
  ];

  public const REQUIRED_WEBHOOK_METHODS = [
    'payload_data'
  ];

  /**
   * Construct our membership plugin's accessible properties and methods,
   * and ensure all required properties/methods are defined
   */
  function __construct($properties = []) {
    foreach ($properties as $key => $value) {
      $this->{$key} = $value;
    }

    foreach (self::REQUIRED_PROPERTIES as $key) {
      if (!isset($this->{$key})) {
        throw new Exception("Membership Plugin class did not define property `$key`.");
      };
    }

    self::require_subclass_methods(self::REQUIRED_BASE_METHODS);
  }

  /**
   * Parent init to perform all common membership plugin actions
   */
  public static function init() {
    $access_token = Utils::get_option('access_token');

    // If the subclass uses WEBHOOK_EVENTS
    // we set up webhook delivery events
    // NOT required for all membership plugins
    $called_class = get_called_class();
    $webhooks_const = $called_class . "::WEBHOOK_EVENTS";
    if (defined($webhooks_const)) {
      self::require_subclass_methods(self::REQUIRED_WEBHOOK_METHODS);

      foreach (constant($webhooks_const) as $event) {
        add_action($event, function() use($called_class, $event, $access_token) {
          $args = func_get_args();
          $data = $called_class::payload_data($event, $args);

          if ($called_class::should_deliver_payload()) {
            self::deliver_payload($data, $access_token);
          }
        }, 100, 10);
      }
    }
  }

  /**
   * Deliver a payload to the Supercast webhook
   */
  public static function deliver_payload($data, $token) {
    return Utils::request(
      Utils::HTTP_POST,
      Utils::root_url() . '/webhooks/' . Utils::$membership_plugin->webhook_endpoint . '/events?access_token=' . $token,
      $data,
      null,
      false
    );
  }

  /**
   * Require sublcasseses to implement methods
   */
  public static function require_subclass_methods($methods) {
    foreach ($methods as $method) {
      if (!method_exists(get_called_class(), $method)) {
        throw new Exception("Membership Plugin class did not define method `$method`.");
      };
    }
  }
}
