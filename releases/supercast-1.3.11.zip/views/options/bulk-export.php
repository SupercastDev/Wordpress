<div class="wrap">
  <h1>Export Customers for Supercast</h1>

  <p>Bulk export customers from your membership plugin into a CSV file compatible with Supercast.</p>
  <p>Once downloaded, visit <strong>Subscribers</strong> > <strong>Import</strong> on your Supercast dashboard to create new subscribers from this file.</p>

  <form method="post" action="admin.php?page=supercast-export" novalidate="novalidate">
    <input type="hidden" name="page" value="supercast-export">
    <input type="hidden" name="action" value="create">
    <?php wp_nonce_field($utils::IDENTIFIER); ?>

    <table class="form-table">
      <tbody>
        <tr>
          <th scope="row">
            <label for="export_ids">Plans to Include</label>
          </th>
          <td>
            <fieldset>
              <input type="hidden" name="export_ids[]" value="" />

              <?php foreach ($utils::$membership_plugin->feed_access_items() as $item) : ?>
                <fieldset>
                  <label for="export_id-<?php echo $item['id'] ?>">
                    <input
                      name="export_ids[]"
                      type="checkbox"
                      id="export_id-<?php echo $item['id'] ?>"
                      value="<?php echo $item['id'] ?>"
                      checked
                    />
                    <?php echo $item['title'] ?>
                  </label>
                </fieldset>
              <?php endforeach; ?>
            </fieldset>
          </td>
        </tr>
      </tbody>
    </table>

    <p class="submit">
      <input type="submit" name="submit" id="submit" class="button button-primary" value="Export Customers">
    </p>
  </form>
</div>
