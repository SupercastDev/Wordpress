<?php use Supercast_Utilities as Utils; ?>

<script src="https://app.supercast.com/js/embed.js"></script>
<supercast-player-links subdomain="<?php echo $subdomain ?>" subscription-identifier="<?php echo $customer_id ?>" />
