var Supercast = Supercast || {};

Supercast.createQuestion = function() {
  var form = document.querySelector('.supercast-ask-question');

  if (form == null) { return; }

  var titleField = form.querySelector('.supercast-question-title');
  var bodyField = form.querySelector('.supercast-question-body');
  var button = form.querySelector('.supercast-question-submit');
  var submitting = false;

  function submitError() {
    button.innerText = 'Submit';
    alert('Sorry, there was an error submitting your question. Please try again later.');
  }

  function sendToUpdatedAddress(questionId) {
    var address = window.location.toString();
    var hashIndex = address.indexOf('#question-');
    var newLocation;

    if (hashIndex > 0) {
      newLocation = address.slice(0, hashIndex) + '#question-' + questionId;
    } else {
      newLocation = address + '#question-' + questionId;
    }

    window.location = newLocation;
    window.location.reload();
  }

  function submitQuestion() {
    // Use to sanitize input
    var tempDiv = document.createElement('div');
    var data = { channel: form.dataset.channel };

    tempDiv.innerHTML = titleField.value;
    data.title = tempDiv.innerText;

    tempDiv.innerHTML = bodyField.value;
    data.body = tempDiv.innerText;

    if (!data.title.length || !data.body.length) {
      return alert('Both a title and your question are required to submit.');
    }

    submitting = true;
    button.innerText = 'Submitting...';
    button.classList.add('disabled');

    var request = jQuery.ajax({
      url: Supercastl10n.site_url + '/wp-json/supercast/v1/questions',
      method: 'POST',
      data: data,
      beforeSend: function(xhr) {
        xhr.setRequestHeader('X-WP-Nonce', Supercastl10n.nonce);
      }
    });

    request.done(function(response, textStatus, jqXHR) {
      if (jqXHR.status !== 200) {
        return submitError();
      }

      button.innerText = 'Question Submitted!';
      titleField.value = '';
      bodyField.value = '';

      setTimeout(function() {
        sendToUpdatedAddress(response.data.id);

        button.innerText = 'Submit';
      }, 1000);
    });

    request.fail(function(jqXHR, data) {
      console.log(jqXHR, data);
      submitError();
    });

    request.always(function() {
      button.classList.remove('disabled');
      submitting = false;
    });
  }

  if (form == null) { return; }

  form.addEventListener('submit', function(event) {
    event.preventDefault();

    if (submitting) { return; }

    submitQuestion();
  });
};

Supercast.createQuestion();
