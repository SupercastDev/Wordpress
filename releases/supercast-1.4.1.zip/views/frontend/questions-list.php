<?php use Supercast_Utilities as Utils; ?>

<form class="supercast-questions-filters">
  <?php foreach ($_GET as $key => $value) :
    if ($key != 'type' && $key != 'query' && $key != 'ama_page') : ?>
      <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>" / >
    <?php endif;
  endforeach; ?>

  <input type='hidden' name='ama_page' value="<?php echo $ama_page; ?>" />

  <div class="supercast-questions-type">
    <label>
      <input type="radio" name="type" value="featured" <?php echo $filters['type'] == 'featured' ? 'checked="checked"' : ''; ?> />
      <span>Featured</span>
    </label>

    <label>
      <input type="radio" name="type" value="responded" <?php echo $filters['type'] == 'responded' ? 'checked="checked"' : ''; ?> />
      <span>Answered</span>
    </label>

    <label>
      <input type="radio" name="type" value="unresponded" <?php echo $filters['type'] == 'unresponded' ? 'checked="checked"' : ''; ?> />
      <span>Unanswered</span>
    </label>

    <label>
      <input type="radio" name="type" value="popular" <?php echo $filters['type'] == 'popular' ? 'checked="checked"' : ''; ?> />
      <span>Most Popular</span>
    </label>
  </div>

  <div class="supercast-questions-search supercast-field-container inline">
    <input type="search" name="query" placeholder="Search for a question..." value="<?php echo !empty($filters['query']) ? $filters['query'] : ''; ?>" />
    <button type="submit">Search</button>
  </div>

  <?php if (isset($filters['type']) && $filters['type'] == 'responded') : ?>
    <div class='supercast-questions-type'>
      <label>
        <input type="radio" name="sort" value="responded_at" <?php echo $filters['sort'] != 'question_participations_count' ? 'checked="checked"' : ''; ?> />
        <span>Recent</span>
      </label>

      <label>
        <input type="radio" name="sort" value="question_participations_count" <?php echo $filters['sort'] == 'question_participations_count' ? 'checked="checked"' : ''; ?> />
        <span>Popular</span>
      </label>
    </div>
  <?php endif; ?>

  <?php if (isset($filters['type']) && $filters['type'] == 'unresponded') : ?>
    <div class='supercast-questions-type'>
      <label>
        <input type="radio" name="sort" value="created_at" <?php echo $filters['sort'] != 'question_participations_count' ? 'checked="checked"' : ''; ?> />
        <span>Recent</span>
      </label>

      <label>
        <input type="radio" name="sort" value="question_participations_count" <?php echo $filters['sort'] == 'question_participations_count' ? 'checked="checked"' : ''; ?> />
        <span>Popular</span>
      </label>
    </div>
  <?php endif; ?>
</form>

<div class="supercast-questions">
  <?php if (count($questions) == 0) : ?>
    <?php if (!empty($filters['query'])) : ?>
      <p class="supercast-no-questions">Sorry, no results for <span><?php echo $filters['query']; ?></span>.</p>
    <?php else : ?>
      <p class="supercast-no-questions">No questions here yet.</p>
    <?php endif; ?>
  <?php endif; ?>

  <?php foreach ($questions as $index => $question) : ?>
    <div class="supercast-question" id="question-<?php echo $question['id']; ?>">
      <div class="supercast-question-actions">
        <?php $active_class = $question['currently_participating'] ? 'active' : null; ?>
        <?php if (Utils::logged_in()) : ?>
          <a
            href="#"
            class="supercast-toggle-participation logged-in <?php echo $active_class; ?>"
            data-question-id="<?php echo $question['id'] ?>"
            data-channel="<?php echo $channel; ?>">
        <?php else :?>
          <a
            href="<?php echo wp_login_url($_SERVER['REQUEST_URI']); ?>"
            class="supercast-toggle-participation <?php echo $active_class; ?>">
        <?php endif; ?>
          <svg verion="1.1" role="img" width="25" height="25" viewBox="0 0 50 76" aria-label="Like">
            <g><g><path d="M30.5,56c-2.5,0-5.2-0.4-8-1.1c-3.7-1-7-1.3-10.1-1.1c-0.7,0.1-1.4,0.1-2.1,0.2l-1.5,0.2c-0.5,0.1-0.9-0.2-1.1-0.7    c-2.5-7.5-3.3-15.5-2.3-24.4c0-0.5,0.4-0.8,0.9-0.9l0.9-0.1c0.7-0.1,1.3-0.2,2-0.2c1-0.1,1.9-0.6,2.6-1.5l0.1-0.2    c0.1-0.1,0.2-0.3,0.3-0.5c1.8-3,4.4-5.3,7.3-7.8c1.5-1.3,2.8-2.6,4-3.8c1.3-1.5,2-3.4,2.1-5.6c0-2,1.1-3.2,3.2-3.4    c2.7-0.2,4.5,0.8,5.5,3.3c1.5,3.4,1.3,6.9-0.6,10.5c-0.4,0.8-0.9,1.5-1.4,2.2c-0.2,0.3-0.4,0.6-0.6,0.9l-0.7,1    c-0.3,0.4-0.6,0.8-0.9,1.3c0.8,0,1.5,0,2.3,0c2.2-0.1,4.7-0.1,7.1,0.3c1.5,0.2,2.7,1,3.5,2.1c0.7,1,0.9,2.3,0.6,3.7    c-0.1,0.6-0.4,1.2-1,1.9c-0.3,0.4-0.7,0.8-1.1,1.1c0,0,0,0,0,0c0.5,0.4,1,0.8,1.4,1.3c0.8,0.9,1.1,1.9,1,3.1    c-0.1,1.1-0.6,2.2-1.5,2.9c-0.5,0.4-1,0.8-1.5,1.1c1,1.1,1.4,2.5,1.1,4c-0.4,2-1.5,3.2-3.6,3.7c0.5,0.8,0.6,1.8,0.3,2.8    c-0.1,0.5-0.3,0.9-0.5,1.3c-0.5,1.1-1.3,1.7-2.6,2C33.9,55.8,32.2,56,30.5,56z M14.5,51.7c2.7,0,5.5,0.4,8.6,1.2    c4.5,1.2,8.4,1.4,12,0.6c0.7-0.2,1-0.5,1.2-0.9c0.2-0.4,0.3-0.7,0.4-1c0.2-0.6,0.1-1.1-0.2-1.5c-0.2-0.3-0.7-0.9-0.4-1.7    c0.3-0.8,1.1-0.9,1.4-1c1.8-0.3,2.3-1.1,2.5-2.2c0.2-1.1-0.1-1.9-0.8-2.6c-0.2-0.2-0.7-0.6-0.6-1.3c0.1-0.7,0.6-1.1,0.9-1.2    l0.3-0.2c0.5-0.3,0.9-0.6,1.3-1c0.5-0.4,0.8-1,0.8-1.5c0-0.6-0.2-1.1-0.5-1.6c-0.4-0.4-0.8-0.8-1.3-1.2l-0.2-0.2    c-0.4-0.3-0.6-0.7-0.7-1.2c0-0.3,0.1-0.8,0.5-1.2c0.1-0.1,0.3-0.3,0.4-0.4c0.3-0.3,0.6-0.6,0.8-0.9c0.3-0.4,0.5-0.8,0.6-1.1    c0.2-0.8,0.1-1.5-0.3-2.1c-0.4-0.7-1.2-1.1-2.2-1.3c-2.3-0.4-4.6-0.3-6.7-0.3c-1.1,0-2.2,0-3.2,0c0,0,0,0,0,0    c-0.7,0-1.2-0.3-1.4-0.8c-0.3-0.5-0.2-1.1,0.2-1.6c0.5-0.7,0.9-1.3,1.4-2l0.7-1c0.2-0.3,0.4-0.6,0.7-0.9c0.5-0.6,0.9-1.3,1.3-1.9    c1.6-3.1,1.8-5.9,0.6-8.8c-0.7-1.7-1.7-2.2-3.5-2.1c-1,0.1-1.3,0.4-1.3,1.4c0,2.8-0.9,5.1-2.6,7c-1.2,1.3-2.6,2.7-4.2,4    c-2.7,2.4-5.2,4.5-6.9,7.3c-0.1,0.2-0.3,0.5-0.5,0.7l-0.1,0.2c-1.1,1.3-2.4,2.1-3.9,2.3c-0.7,0.1-1.3,0.2-2,0.3l-0.1,0    c-0.7,8-0.1,15.2,2.1,22l0.7-0.1c0.7-0.1,1.4-0.2,2.2-0.2C13,51.8,13.7,51.7,14.5,51.7z"/></g></g>
          </svg>
          <span><?php echo $question['participant_count'] ?></span>
        </a>
      </div>

      <div class="supercast-question-details">
        <h3><?php echo $question['title']; ?></h3>
        <p><?php echo preg_replace("/\r\n|\r|\n/", '<br/>', $question['body']); ?></p>

        <?php if ($question['state'] == 'responded' && $user->ID != 0) : ?>
          <div class="supercast-question-response">
            <small>
              <svg class="checkmark" verion="1.1" role="img" width="14" height="10" viewBox="0 0 14 10" aria-label="Checkmark icon">
                <path d="m27.6363636 123-8 8-3.6363636-3.636364" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" transform="translate(-15 -122)"/>
              </svg>
              Answered <?php echo Utils::time_ago(strtotime($question['responded_at'])); ?>
              <?php if ($question['response_episode'] != null) : ?>
                in&#8230;

                <div class="supercast-question-response-info">
                  <?php $player_data = [
                    'audio_url' => $question['response_episode']['audio_url'],
                    'timestamp' => $question['response_timestamp'],
                    'title' => $question['response_episode']['title']
                  ]; ?>

                  <a href="#" class="play-button" data-player-data="<?php echo htmlspecialchars(json_encode($player_data)); ?>">
                    <svg verion="1.1" role="img" width="15" height="16" viewBox="0 0 15 16" aria-label="Play icon">
                      <path d="m14.051 9.377-11.196 6.298c-.48924196.2753798-1.08786938.2704611-1.57252022-.0129208-.48465084-.2833818-.78247978-.8026598-.78247978-1.3640792v-12.596c0-.56141936.29782894-1.08069742.78247978-1.36407925.48465084-.28338183 1.08327826-.2883005 1.57252022-.01292075l11.196 6.298c.4974165.27987232.8052284.80625337.8052284 1.377s-.3078119 1.09712768-.8052284 1.377z" />
                    </svg>
                  </a>

                  <h5><?php echo $question['response_episode']['title']; ?></h5>
                </div>
              <?php endif; ?>

              <div class="supercast-question-response-text">
                <?php echo $question['response']; ?>
              </div>
            </small>
          </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>

  <div class='supercast-pagination'>
    <?php if ($hasPrev) : ?>
      <a href='' class="supercast-previous-page">Previous</a>
    <?php endif; ?>

    <?php if ($hasNext) : ?>
      <a href='#' class="supercast-next-page">Next</a>
    <?php endif; ?>
  </div>
</div>
