<?php

if (!defined('ABSPATH')) { die('Access denied'); }

use Supercast_Utilities as Utils;

class Supercast_API {
  /**
   * Currently only v1 of the API is available
   */
  public const API_VERSION = 'v1';

  /**
   * All properties that you're allowed to pass along with a user request
   */
  public const USER_PROPERTIES = [
    'email',
    'first_name',
    'last_name',
    'state'
  ];

  /**
   * Set up an API path
   */
  private static function api_path($path) {
    return '/api/' . self::API_VERSION . $path;
  }

  /**
   * Get a specific
   */
  public static function get_user($user) {
    return Utils::request(
      Utils::HTTP_GET,
      self::api_path('/subscribers/' . urlencode($user->user_email)),
      ['recursive' => true],
      Utils::get_option('access_token')
    );
  }

  /**
   * Send a login SMS to a user
   */
  public static function login_sms($user, $phone) {
    return Utils::request(
      Utils::HTTP_POST,
      self::api_path('/sms/' . urlencode($user->user_email)),
      [
        'phone_number' => filter_var($phone, FILTER_SANITIZE_NUMBER_INT)
      ],
      Utils::get_option('access_token')
    );
  }

  /**
   * Retrieve all channel questions
   */
  public static function get_questions($channel, $user, $filters) {
    return Utils::request(
      Utils::HTTP_GET,
      self::api_path("/questions"),
      array_merge([
        'channel_subdomain' => $channel,
        'user' => $user->user_email
      ], $filters),
      Utils::get_option('access_token')
    );
  }

  /**
   * Retrieve all channel questions
   */
  public static function create_question($user, $channel, $title, $body) {
    return Utils::request(
      Utils::HTTP_POST,
      self::api_path("/questions"),
      [
        'channel_subdomain' => $channel,
        'user' => $user->user_email,
        'question' => [
          'title' => $title,
          'body' => $body
        ]
      ],
      Utils::get_option('access_token')
    );
  }

  /**
   * Get a question
   */
  public static function get_question($user, $channel, $question_id) {
    return Utils::request(
      Utils::HTTP_GET,
      self::api_path("/questions/$question_id"),
      [
        'channel_subdomain' => $channel,
        'user' => $user->user_email
      ],
      Utils::get_option('access_token')
    );
  }

  /**
   * Delete a question
   */
  public static function delete_question($user, $channel, $question_id) {
    return Utils::request(
      Utils::HTTP_DELETE,
      self::api_path("/questions/$question_id"),
      [
        'channel_subdomain' => $channel,
        'user' => $user->user_email
      ],
      Utils::get_option('access_token')
    );
  }

  /**
   * Toggle participation in a question
   */
  public static function toggle_question_participation($user, $channel, $question_id) {
    return Utils::request(
      Utils::HTTP_PATCH,
      self::api_path("/questions/$question_id/participate"),
      [
        'channel_subdomain' => $channel,
        'user' => $user->user_email
      ],
      Utils::get_option('access_token')
    );
  }
}
