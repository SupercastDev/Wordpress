<?php

if (!defined('ABSPATH')) { die('Access denied'); }

require_once(SUPERCAST_PLUGIN_DIR . 'lib/membership-plugins/base.php');

use Supercast_Utilities as Utils;
use Supercast_MembershipPlugin_Base as Base;

class Supercast_MembershipPlugin_MemberPress extends Base {
  /**
   * Any event that should trigger a webhook payload
   */
  public const WEBHOOK_EVENTS = [
    'mepr_subscription_saved',
    'profile_update',
    'mepr_subscription_status_active',
    'mepr_subscription_status_cancelled',
    'mepr_subscription_status_suspended',
    'mepr_subscription_status_pending',
    'mepr_subscription_pre_delete',
    'mepr_subscription_deleted'
  ];

  /**
   * Initializes the MemberPress membership plugin
   */
  public static function init() {
    Utils::use_membership_plugin(new self([
      'name' => 'MemberPress',
      'webhook_endpoint' => 'word_press/member_press',
      'website_url' => 'https://memberpresss.com/',
      'support_url' => 'https://memberpress.com/support',
    ]));

    add_action('mepr_member_data_updater_worker', [
      'Supercast_MembershipPlugin_MemberPress',
      'cron_update_expired_subscriptons'
    ]);

    parent::init();
  }

  /**
   * Return all MemberPress products as an id/title array
   */
  public function feed_access_items() {
    $mepr_product_map = function($product) {
      return [
        'id' => $product->ID,
        'title' => $product->post_title
      ];
    };

    return array_map($mepr_product_map, \MeprProduct::get_all());
  }

  /**
   * Check if the user locally has access to a feed
   */
  public function user_can_access($user) {
    return self::user_has_active_subscriptions($user);
  }

  /**
   * Print additional notes for installation instructions
   */
  public function installation_note() { ?>
    <p>You're all set. Changes to your MemberPress subscriptions above will be automatically sent to Supercast.</p>
  <?php }

  /**
   * Creates a CSV of active subscription holders
   */
  public static function export_subscribers($list_ids_to_use) {
    global $wpdb;
    $mepr_db = new MeprDb();

    if (!\MeprUtils::is_mepr_admin()) { return; }

    $q = "SELECT
      user.user_email      AS email,
      frst.meta_value      AS first_name,
      last.meta_value      AS last_name,
      user.user_registered AS created_at,
      prod.post_title      AS membership
      FROM {$wpdb->users} AS user
        LEFT JOIN {$wpdb->usermeta} AS frst
          ON user.ID = frst.user_id AND frst.meta_key = 'first_name'
        LEFT JOIN {$wpdb->usermeta} AS last
          ON user.ID = last.user_id AND last.meta_key = 'last_name'
        INNER JOIN {$mepr_db->transactions} AS trxn
          ON user.ID = trxn.user_id
            AND (trxn.status = 'complete' OR trxn.status = 'confirmed')
            AND (trxn.expires_at IS NULL OR trxn.expires_at = 0 OR trxn.expires_at >= '" . date('c') . "')
        LEFT JOIN {$wpdb->posts} AS prod
          ON trxn.product_id = prod.ID
      WHERE trxn.product_id IN (". implode(',', $list_ids_to_use) . ")";

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=memberpress_export.csv');

    $output = fopen('php://output', 'w');

    fputcsv($output, [
      'Email',
      'First Name',
      'Last Name',
      'Created At',
      'Subscription'
    ]);

    $wpdb->query("SET SQL_BIG_SELECTS=1");
    $rows = $wpdb->get_results($q, ARRAY_A);

    foreach($rows as $row) {
      fputcsv($output, $row);
    }

    fclose($output);
    exit;
  }

  /**
   * Sets up the data we want to deliver as a payload to Supercast
   */
  public static function payload_data($event_name, $args = []) {
    $data = [
      'timestamp' => current_time('timestamp'),
      'memberpress_event' => true
    ];

    if ($event_name === 'uninstalled') {
      $data['event_name'] = 'uninstalled';
    } elseif ($event_name === 'profile_update') {
      $data['event_name'] = 'profile_update';

      $data['user'] = [
        'email' => $args[1]->user_email,
        'data' => [
          'email' => Utils::get_user($args[0])->user_email,
          'first_name' => Utils::get_user($args[0])->first_name,
          'last_name' => Utils::get_user($args[0])->last_name,
        ]
      ];
    } else {
      $data['event_name'] = 'memberpress_update';
      $data['mepr_event_name'] = $event_name;

      foreach ($args as $arg) {
        if (isset($arg->subscription_id) && empty($data['subscription'])) {
          $data['subscription'] = self::parsed_subscription(
            new MeprSubscription($arg->subscription_id)
          );
        }

        if (isset($arg->transaction_id) && empty($data['transaction'])) {
          $data['transaction'] = self::parsed_transaction(
            new MeprTransaction($arg->transaction_id)
          );
        }

        if (isset($arg->user_id) && empty($data['user'])) {
          $data['user'] = self::parsed_user(
            new MeprUser($arg->user_id)
          );
        }

        if (isset($arg->product_id) && empty($data['product'])) {
          $data['product'] = self::parsed_product(
            new MeprProduct($arg->product_id)
          );
        }

        if (isset($arg->membership_id) && empty($data['product'])) {
          $data['product'] = self::parsed_product(
            new MeprProduct($arg->membership_id)
          );
        }

        if ($arg instanceof MeprSubscription && empty($data['subscription'])) {
          $data['subscription'] = self::parsed_subscription($arg);
        }

        if ($arg instanceof MeprTransaction && empty($data['transaction'])) {
          $data['transaction'] = self::parsed_transaction($arg);
        }

        if ($arg instanceof MeprUser && empty($data['user'])) {
          $data['user'] = self::parsed_user($arg);
        }

        if (($arg instanceof MeprProduct || $arg instanceof MeprMembership) &&
          empty($data['product'])) {
          $data['product'] = self::parsed_product($arg);
        }
      }

      $subscription_pairs = array_filter(Utils::get_option('subscription_pairs'));
      $subscribable_plans = array_filter(Utils::get_option('subscribable_plans'));
      $product = $data['product'];

      if (!empty($product) && $subscription_pairs[$product['id']]) {
        $pair = $subscription_pairs[$product['id']];

        $paired_plan = array_filter($subscribable_plans, function($plan) use($pair) {
          # Example pair id: 'network_12'
          return sprintf("%s_%d", $plan['type'], $plan['id']) == $pair['id'];
        });

        if (!empty($paired_plan)) {
          $plan = array_values($paired_plan)[0];

          if ($plan['type'] == 'channel') {
            $data['channel_subdomain'] = $plan['subdomain'];
          } else if ($plan['type'] == 'network') {
            $data['bundle_id'] = intval($plan['id']);
          }
        }
      }
    }

    return array_filter($data);
  }

  /**
   * Returns data parsed from a MeprUser object
   */
  public static function parsed_user($user) {
    return [
      'id'                => $user->ID,
      'email'             => $user->user_email,
      'first_name'        => $user->first_name,
      'last_name'         => $user->last_name,
      'registration_date' => MeprUser::get_user_registration_date($user->ID),
      'has_active_sub'    => self::user_has_active_subscriptions($user)
    ];
  }

  /**
   * Returns data parsed from a MeprProduct object
   */
  public static function parsed_product($product) {
    return [
      'id'    => $product->ID,
      'title' => $product->pricing_title,
      'value' => $product->price
    ];
  }

  /**
   * Returns data parsed from a MeprSubscription object
   */
  public static function parsed_subscription($subscription) {
    $active = $subscription->status == 'active';
    $expiring_txn = $subscription->expiring_txn();

    if (!$active && $expiring_txn != false) {
      $active = (time() <= strtotime($expiring_txn->expires_at));
    }

    return [
      'id'          => $subscription->ID,
      'number'      => $subscription->subscr_id,
      'active'      => $active,
      'gateway'     => $subscription->gateway,
      'expires_at'  => $subscription->get_expires_at(),
      'created_at'  => $subscription->created_at
    ];
  }

  /**
   * Returns data parsed from a MeprTransaction object
   */
  public static function parsed_transaction($transaction) {
    return [
      'id'         => $transaction->id,
      'status'     => $transaction->status,
      'number'     => $transaction->trans_num,
      'net'        => $transaction->amount,
      'tax'        => $transaction->tax_amount,
      'total'      => $transaction->total,
      'gateway'    => $transaction->gateway,
      'created_at' => $transaction->created_at,
      'expires_at' => $transaction->expires_at
    ];
  }

  /**
   * MemberPress specific method to check if the current user
   * has any active subscriptions in the chosen membership categories
   */
  public static function user_has_active_subscriptions($user) {
    global $wpdb;

    $mepr_db = MeprDb::fetch();
    $subscription_pair_ids = array_keys(array_filter(Utils::get_option('subscription_pairs')));
    $active_subs = $wpdb->get_var("SELECT COUNT(*) FROM {$mepr_db->subscriptions} WHERE product_id IN (".implode(',',$subscription_pair_ids).") AND user_id = {$user->ID} AND status = 'active'");

    return $active_subs > 0;
  }

  /**
   * Checks if the payload should actually be delivered
   */
  public static function should_deliver_payload() {
    return count(Utils::get_option('subscription_pairs')) > 0;
  }

  /**
   * Tell Supercast about expired subscriptions
   * based on the `mepr_member_data_updater_worker` cron
   */
  public static function cron_update_expired_subscriptons() {
    $access_token = Utils::get_option('access_token');
    $subscriptions = self::recently_expired_subscriptions();

    foreach($subscriptions as $subscription) {
      $data = self::payload_data('cron_update_expired_subscriptons', [$subscription]);
      parent::deliver_payload($data, $access_token);
    }
  }

  /**
   * Get recently expired subs
   */
  public static function recently_expired_subscriptions() {
    global $wpdb;

    $mepr_db = MeprDb::fetch();

    $query = $wpdb->prepare("
        SELECT transaction.subscription_id
          FROM {$mepr_db->transactions} as transaction
         WHERE (transaction.expires_at >= %s AND
                transaction.expires_at <= %s AND
                transaction.status IN (%s,%s))
               OR transaction.expires_at = %s
      GROUP BY transaction.subscription_id
        HAVING SUM(transaction.expires_at = %s) = 0
      ",
      MeprUtils::ts_to_mysql_date(time() - 21600), // 6 hours ago
      MeprUtils::db_now(), // right now
      MeprTransaction::$confirmed_str,
      MeprTransaction::$complete_str,
      MeprUtils::db_lifetime(),
      MeprUtils::db_lifetime()
    );

    $subscriptions_ids = $wpdb->get_col($query);

    if (empty($subscriptions_ids)) { return []; }

    $subscriptions = [];

    foreach($subscriptions_ids as $subscriptions_id) {
      $subscriptions[] = new MeprSubscription($subscriptions_id);
    }

    return $subscriptions;
  }
}
