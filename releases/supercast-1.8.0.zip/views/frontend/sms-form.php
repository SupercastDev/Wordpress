<form class="supercast-field-container supercast-sms inline">
  <input class="supercast-sms-phone" type="tel" placeholder="Your phone number"/>
  <button class="supercast-sms-submit">Send</button>
</form>
