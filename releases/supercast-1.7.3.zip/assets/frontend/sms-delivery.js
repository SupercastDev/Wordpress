var Supercast = Supercast || {};

Supercast.smsDelivery = function() {
  var form = document.querySelector('.supercast-sms');

  if (form == null) { return; }

  var field = form.querySelector('.supercast-sms-phone');
  var button = form.querySelector('.supercast-sms-submit');
  var submitting = false;

  function smsError() {
    button.innerText = 'Send';
    alert('Sorry, there was an error submitting this SMS request. Please try again later.');
  }

  function sendSMS() {
    var phoneValue = field.value.replace(/\D/g,'');

    if (phoneValue == null || !phoneValue.length) {
      return alert('Please enter a valid phone number.');
    }

    submitting = true;
    button.innerText = 'Sending...';
    button.classList.add('disabled');

    var request = jQuery.ajax({
      url: Supercastl10n.site_url + '/wp-json/supercast/v1/sms',
      method: 'POST',
      data: { phone_number: phoneValue },
      beforeSend: function(xhr) {
        xhr.setRequestHeader('X-WP-Nonce', Supercastl10n.nonce);
      }
    });

    request.done(function(data, textStatus, jqXHR) {
      if (jqXHR.status !== 200) {
        return smsError();
      }

      button.innerText = 'Sent!';

      setTimeout(function() {
        button.innerText = 'Send';
      }, 1000);
    });

    request.fail(function(jqXHR, data) {
      console.log(jqXHR, data);
      smsError();
    });

    request.always(function() {
      button.classList.remove('disabled');
      submitting = false;
    });
  }

  if (form == null) { return; }

  form.addEventListener('submit', function(event) {
    event.preventDefault();

    if (submitting) { return; }

    sendSMS();
  });
};

Supercast.smsDelivery();
