var Supercast = Supercast || {};

Supercast.listQuestions = function() {
  var questionId = new URL(location.href).searchParams.get('question_id');
  var channelSubdomain = new URL(location.href).searchParams.get('channel_subdomain');
  Supercast.loadQuestion(questionId, channelSubdomain);

  var questions = document.querySelectorAll('.supercast-question');

  [].forEach.call(questions, Supercast.initQuestion);

  var questionTypeRadios = document.querySelectorAll('.supercast-questions-filters input[type="radio"]');

  [].forEach.call(questionTypeRadios, function(radio, index) {
    radio.addEventListener('change', function() {
      form = this.closest('form');
      form.elements["ama_page"].value = 1;
      form.elements["query"].value = "";
      form.submit();
    });
  });

  var links = document.querySelectorAll('.supercast-question-response-text a');
  [].forEach.call(links, function(link) {
    link.target = "_blank";
  });

  Supercast.initPagination();
};

Supercast.initPagination = function() {
  var nextPage = document.querySelector('.supercast-next-page');
  var prevPage = document.querySelector('.supercast-previous-page');
  var form = document.querySelector('.supercast-questions-filters');

  if (nextPage) {
    nextPage.addEventListener('click', function(e) {
      e.preventDefault();
      form.elements['ama_page'].value = parseInt(form.elements['ama_page'].value) + 1;
      form.submit();
    })
  }

  if (prevPage) {
    prevPage.addEventListener('click', function(e) {
      e.preventDefault();
      form.elements['ama_page'].value = parseInt(form.elements['ama_page'].value) - 1;
      form.submit();
    })
  }
}

Supercast.initQuestion = function(question) {
  var participateLink = question.querySelector('.supercast-toggle-participation.logged-in');
  var deleteLink = question.querySelector('.supercast-delete-question');
  var playButton = question.querySelector('.play-button');

  if (participateLink != null) {
    participateLink.addEventListener('click', Supercast.toggleQuestionParticipation);
  }

  if (deleteLink != null) {
    deleteLink.addEventListener('click', Supercast.deleteQuestion);
  }

  if (playButton != null) {
    playButton.addEventListener('click', Supercast.playResponse);
  }
};

Supercast.toggleQuestionParticipation = function(event) {
  event.preventDefault();

  var request = jQuery.ajax({
    url: Supercastl10n.site_url + '/wp-json/supercast/v1/questions/' + this.dataset.questionId + '/participate',
    method: 'PATCH',
    data: { channel: this.dataset.channel },
    beforeSend: function(xhr) {
      xhr.setRequestHeader('X-WP-Nonce', Supercastl10n.nonce);
    }
  });

  request.done(function(response, textStatus, jqXHR) {
    this.classList[response.data.participating ? 'add' : 'remove']('active');
    this.querySelector('span').textContent = response.data.count;
  }.bind(this));

  request.fail(function(jqXHR, data) {
    console.log(jqXHR, data);
    alert('Whoops, sorry. There was a problem with that request. Try again?')
  });
};

Supercast.deleteQuestion = function(event) {
  event.preventDefault();

  if (!confirm('Are you sure you want to delete your question? This cannot be undone!')) { return; }

  var question = this.closest('.supercast-question');

  var request = jQuery.ajax({
    url: Supercastl10n.site_url + '/wp-json/supercast/v1/questions/' + this.dataset.questionId,
    method: 'DELETE',
    data: { channel: this.dataset.channel },
    beforeSend: function(xhr) {
      xhr.setRequestHeader('X-WP-Nonce', Supercastl10n.nonce);
    }
  });

  request.done(function(response, textStatus, jqXHR) {
    question.parentNode.removeChild(question);
  }.bind(this));

  request.fail(function(jqXHR, data) {
    console.log(jqXHR, data);
    alert('Whoops, sorry. There was a problem deleting the question. Try again?')
  });
};

Supercast.playResponse = function(event) {
  event.preventDefault();

  var playerData = this.dataset.playerData;
  if (!playerData || !playerData.length) { return; }

  Supercast.Player.setAudio(JSON.parse(playerData), true);
};

Supercast.loadQuestion = function(questionId, channelSubdomain) {
  if (!questionId || !channelSubdomain) { return; }

  var request = jQuery.ajax({
    url: Supercastl10n.site_url + '/wp-json/supercast/v1/questions/' + questionId,
    method: 'GET',
    data: { channel: channelSubdomain },
    beforeSend: function(xhr) {
      xhr.setRequestHeader('X-WP-Nonce', Supercastl10n.nonce);
    }
  });

  request.done(function(response, textStatus, jqXHR) {
    if (response.data.state != 'responded') { return; }

    var playerData = {
      audio_url: response.data.response_episode.audio_url,
      transcript: response.data.response,
      timestamp: response.data.response_timestamp,
      title: response.data.response_episode.title
    };

    Supercast.Player.setAudio(playerData);
  }.bind(this));

  request.fail(function(jqXHR, data) {
    console.log(jqXHR, data);
    alert('Whoops, sorry. There was a problem retrieving that Question. Try again?')
  });
}

Supercast.listQuestions();
