<?php

if (!defined('ABSPATH')) { die('Access denied'); }

use Supercast_Utilities as Utils;

class Supercast_Options {
  private static $options_hook = null;
  private static $bulk_export_hook = null;

  /**
   * Sets up our admin pages and hooks
   */
  public static function init() {
    add_action('admin_menu', array('Supercast_Options', 'admin_menus'));
    add_action('admin_enqueue_scripts', array('Supercast_Options', 'load_resources'));

    if (self::is_options_page()) {
      self::perform_options_page();
    }

    if (self::is_export_page()) {
      self::perform_export_page();
    }
  }

  /**
   * Sets up admin menus
   */
  public static function admin_menus() {
    self::$options_hook = add_menu_page(
      'Supercast Options',
      'Supercast',
      'administrator',
      'supercast',
      ['Supercast_Options', 'render_options'],
      file_get_contents(plugins_url('../assets/options/emblem.base64', __FILE__))
    );

    self::$bulk_export_hook = add_submenu_page(
      'options-writing.php',
      'Export Customers for Supercast',
      'Export Customers',
      'administrator',
      'supercast-export',
      ['Supercast_Options', 'render_export']
    );
  }

  /**
   * Load JS and CSS into admin pages
   */
  public static function load_resources($hook) {
    if ($hook == self::$options_hook) {
      wp_enqueue_style(
        'supercast-options-codemirror',
        plugins_url('../assets/options/codemirror.css', __FILE__)
      );

      wp_enqueue_style(
        'supercast-options-core',
        plugins_url('../assets/options/options.css', __FILE__)
      );

      wp_enqueue_script(
        'supercast-options-codemirror',
        plugins_url('../assets/options/codemirror.js', __FILE__)
      );

      wp_enqueue_script(
        'supercast-options-core',
        plugins_url('../assets/options/options.js', __FILE__)
      );
    }
  }

  /**
   * Identify the incoming requests intent by checking `page` and `action` POST values.
   * This is less about security and more about preventing accidental overwrites of data
   */
  public static function is_intent($page, $action) {
    if (!$_POST) {
      return false;
    }

    $page_matches = isset($_POST['page']) && $_POST['page'] == 'supercast-' . $page;
    $action_matches = isset($_POST['action']) && $_POST['action'] == $action;

    return $page_matches && $action_matches;
  }

  /**
   * Render a WP notice
   *
   * IMPORTANT: this renders raw HTML, so ensure your strings are clean!
   */
  public static function notice($type, $messages, $dismissable = true) {
    if (is_string($messages)) { $messages = [$messages]; } ?>
    <div class="notice notice-<?php echo $type; ?> <?php echo ($dismissable ? 'is-dismissible' : null); ?>">
      <?php foreach ($messages as $message) : ?>
        <p><?php echo $message; ?></p>
      <?php endforeach; ?>
    </div>
  <?php }

  /**
   * Check if the current page is the Options page
   */
  public static function is_options_page() {
    global $pagenow;
    return $pagenow == 'admin.php' && $_GET['page'] == 'supercast';
  }

  /**
   * Perform any actions related to the Options page
   */
  public static function perform_options_page() {
    // No membership plugins were found
    if (!Utils::$membership_plugin) {
      add_action('admin_notices', function() {
        return self::notice('info', 'In order to use Supercast for WordPress you’ll need to install one of our supported membership plugins (Memberful, MemberPress, or WooCommerce Subscriptions).', false);
      });
    }

    // More than one membership plugin was detected
    if (Utils::$conflicting_membership_plugins) {
      add_action('admin_notices', function() {
        return self::notice('warning', [
          'It looks like you have multiple membership plugin enabled. Supercast can only use one supported membership plugin.',
          '<b>Using the first membership plugin detected, ' . Utils::$membership_plugin->name . '.</b>'
        ]);
      });
    }

    if (strpos(Utils::DOMAIN, 'staging') !== false) {
      add_action('admin_notices', function() {
        return self::notice('warning', '<b>Heads up!</b> Your plugin instance is targeting Supercast’s Staging server. Please only use Staging accounts and tokens.', false);
      });
    }

    // Options were updated
    if (self::is_intent('options', 'update') && Utils::nonce_valid()) {
      foreach (array_keys(Utils::default_options()) as $key) {
        if (isset($_POST[$key])) {
          $value = $_POST[$key];

          // String settings we need to strip whitespace from
          if (in_array($key, ['access_token'])) {
            $value = trim($value);
          }

          // String settings we need to sanitize
          if (in_array($key, ['access_token', 'subscribable_synced_at', 'subscribable_type', 'general_error', 'account_access_error', 'shortcode_css'])) {
            $value = wp_strip_all_tags($value);
          }

          Utils::update_option($key, $value);
        }

        if (empty($_POST['subscribable_plans'])) {
          Utils::update_option('subscribable_plans', []);
        }

        if (empty($_POST['subscription_pairs'])) {
          Utils::update_option('subscription_pairs', []);
        }
      }

      add_action('admin_notices', function() {
        return self::notice('success', 'Options updated.');
      });

      // This will redirect to the same tab, but it performs an additional
      // request, so we lose any flash messages or other params
      //
      // if (isset($_POST['current_tab'])) {
      //   wp_redirect('admin.php?page=supercast#tab-' . $_POST['current_tab']);
      // }
    }

    // Options were reset
    if (self::is_intent('options', 'reset') && Utils::nonce_valid()) {
      Utils::reset_options();

      add_action('admin_notices', function() {
        return self::notice('success', 'Options have been reset.');
      });
    }

    // Redirected back to options page with error message
    if (isset($_GET['error-message'])) {
      add_action('admin_notices', function() {
        return self::notice('error', $_GET['error-message']);
      });
    }

    // Redirected back to options page with success message
    if (isset($_GET['success-message'])) {
      add_action('admin_notices', function() {
        return self::notice('success', $_GET['success-message']);
      });
    }
  }

  /**
   * Render the Options page
   */
  public static function render_options() {
    $vars = ['root_url' => Utils::root_url()];

    foreach (array_keys(Utils::default_options()) as $key) {
      $vars[$key] = Utils::get_option($key);
    }

    Utils::load_view('options', $vars);
  }

  /**
   * Check if the current page is the Bulk Export page
   */
  public static function is_export_page() {
    global $pagenow;
    return $pagenow == 'admin.php' && $_GET['page'] == 'supercast-export';
  }

  /**
   * Perform any actions related to the OpBulk Exporttions page
   */
  public static function perform_export_page() {
    // Don't allow access to access token page unless a membership plugin is set
    if (!Utils::$membership_plugin) {
      $message = urlencode('An membership plugin is required in order to export Customers.');
      $redirect = add_query_arg('error-message', $message, 'admin.php?page=supercast');
      wp_redirect($redirect);
      exit;
    }

    // More than one membership plugin was detected
    if (Utils::$conflicting_membership_plugins) {
      add_action('admin_notices', function() {
        return self::notice('warning', [
          'It looks like you have multiple membership plugin enabled. Supercast can only use one supported membership plugin.',
          '<b>Using the first membership plugin detected, ' . Utils::$membership_plugin->name . '.</b>'
        ]);
      });
    }

    // Export form was submitted
    if (self::is_intent('export', 'create') && Utils::nonce_valid()) {
      if (!isset($_POST['export_ids']) || empty(array_filter($_POST['export_ids']))) {
        $message = urlencode('Please select at least one access list to export.');
        $redirect = add_query_arg('error-message', $message, 'admin.php?page=supercast-export');
        wp_redirect($redirect);
        exit;
      } else {
        $ids = array_filter($_POST['export_ids'], 'is_numeric');
        return Utils::$membership_plugin::export_subscribers($ids);
      }
    }

    // Redirected back to export page with error message
    if (isset($_GET['error-message'])) {
      add_action('admin_notices', function() {
        return self::notice('error', $_GET['error-message']);
      });
    }

    // Redirected back to export page with success message
    if (isset($_GET['success-message'])) {
      add_action('admin_notices', function() {
        return self::notice('success', $_GET['success-message']);
      });
    }
  }

  /**
   * Render the Bulk Export page
   */
  public static function render_export() {
    $vars = [];

    Utils::load_view('bulk-export', $vars);
  }
}
