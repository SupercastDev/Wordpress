<script type="text/javascript">
  window.scPlanSets = <?php echo json_encode($subscribable_plans); ?>;
</script>

<main class="supercast-plugin-settings">
  <header class="plugin-header wrap">
    <div class="plugin-header-inner">
      <h1 class="header-logo">
        Supercast Options
        <img src="<?php echo plugins_url('../../assets/options/logo.svg', __FILE__) ?>" />
      </h1>

      <p>Use the options below to integrate your WordPress site with Supercast.</p>

      <nav class="header-tab-switch">
        <a href="#tab-general" data-tab="general">General</a>
        <a href="#tab-feeds" data-tab="feeds">Feeds</a>
        <a href="#tab-ama" data-tab="ama">AMA</a>
        <a href="#tab-advanced" data-tab="advanced">Advanced</a>
      </nav>
    </div>
  </header>

  <form class="options-form" method="post" action="admin.php?page=supercast" novalidate="novalidate">
    <input type="hidden" name="current_tab">
    <input type="hidden" name="page" value="supercast-options">
    <input type="hidden" name="action" value="update">
    <?php wp_nonce_field($utils::IDENTIFIER); ?>

    <section data-tab="general" class="tab-content content-split wrap">
      <div>
        <table class="form-table">
          <tbody>
            <tr>
              <th scope="row">
                <label for="access_token">Supercast connection</label>
              </th>
              <td>
                <fieldset class="card sc-card">
                  <p class="title"><label for="access_token">API access token (network or channel)</label></p>
                  <input type="text" id="access_token" name="access_token" class="regular-text access-token-field" value="<?php echo $access_token ?>">
                  <hr />

                  <div class="access-connection">
                    <input
                      type="button"
                      class="button button-secondary"
                      value="Fetch Supercast Channels"
                      data-url="<?php echo $root_url; ?>/api/v1/subscribable"
                      disabled />

                    <p class="description" data-default="First enter an access token (which you can get from your API page in Supercast)."></p>
                  </div>

                  <input type="hidden" class="subscribable-synced-at" name="subscribable_synced_at" value="<?php echo $subscribable_synced_at; ?>" />
                  <input type="hidden" class="subscribable-type" name="subscribable_type" value="<?php echo $subscribable_type; ?>" />

                  <?php foreach ($subscribable_plans as $index => $item) : ?>
                    <input type="hidden" name="subscribable_plans[<?php echo $index; ?>][name]" class="subscribable-plan-input" value="<?php echo $item['name']; ?>">
                    <input type="hidden" name="subscribable_plans[<?php echo $index; ?>][id]" class="subscribable-plan-input" value="<?php echo $item['id']; ?>">
                    <input type="hidden" name="subscribable_plans[<?php echo $index; ?>][type]" class="subscribable-plan-input" value="<?php echo $item['type']; ?>">
                    <input type="hidden" name="subscribable_plans[<?php echo $index; ?>][subdomain]" class="subscribable-plan-input" value="<?php echo $item['subdomain']; ?>">
                  <?php endforeach; ?>
                </fieldset>
              </td>
            </tr>

            <tr>
              <th scope="row">
                <label for="general_error">Shortcode errors</label>
              </th>
              <td>
                <fieldset>
                  <p class="option-title">General error</p>
                  <textarea class="feed-error-input" name="general_error" id="general_error"><?php echo stripslashes($general_error); ?></textarea>
                  <p class="description">Customize the message that us displayed when something, such as an API error, occurs that prevents a shortcode from rendering.</p>

                  <p class="option-title">Account error</p>
                  <textarea class="feed-error-input" name="account_access_error" id="account_access_error"><?php echo stripslashes($account_access_error); ?></textarea>
                  <p class="description">Customize the message that is displayed when a user’s Supercast account cannot be retrieved. Note that this should not be a replacement for restricting content through your membership plugin. Only members that are logged in should be able to see this error.</p>
                </fieldset>
              </td>
            </tr>
          </tbody>
        </table>

        <p class="actions-area">
          <input type="submit" name="commit" class="button button-primary" value="Save Changes">
        </p>
      </div>

      <div class="right-panel"></div>
    </section>

    <section data-tab="feeds" class="tab-content content-split wrap">
      <div>
        <table class="form-table">
          <tbody>
            <?php if (isset($utils::$membership_plugin)) : ?>
              <div class="notice notice-info">
                <p>
                  Detected the membership plugin <a href="<?php echo $utils::$membership_plugin->website_url; ?>" target="_blank"><?php echo $utils::$membership_plugin->name; ?></a>.
                  Refer to their <a href="<?php echo $utils::$membership_plugin->support_url; ?>" target="_blank">support page</a> for help with setting up plans and restricting content for non-members.
                </p>
              </div>

              <tr>
                <th scope="row">
                  <label for="subscription_pairs_select">Applicable subscriptions</label>
                </th>
                <td>
                  <fieldset>
                    <div class="card sc-card">
                      <div class="subscription-pair-select">
                        <?php if (count($subscribable_plans) <= 0) : ?>
                          <p class="pairing-setup-title">You'll need to enter an access token above and fetch channels from Supercast before you can proceed.</p>
                        <?php elseif (count($utils::$membership_plugin->feed_access_items()) > 0) : ?>
                          <select>
                            <option selected="true" disabled="disabled">Select a plan...</option>

                            <?php foreach ($utils::$membership_plugin->feed_access_items() as $item) : ?>
                              <?php if (!in_array($item['id'], array_keys($subscription_pairs))) : ?>
                                <option value="<?php echo $item['id'] ?>"><?php echo $item['title'] ?></option>
                              <?php endif; ?>
                            <?php endforeach; ?>
                          </select>

                          <input type="button" class="button button-secondary" value="Choose" />
                        <?php else : ?>
                          <p class="pairing-setup-title">Create some <?php echo $utils::$membership_plugin->name; ?> plans to set them up with Supercast.</p>
                        <?php endif; ?>
                      </div>

                      <div class="subscription-pair-items">
                        <?php foreach ($subscription_pairs as $id => $plan) : ?>
                          <div class="subscription-pair-item" data-id="39014" data-name="Sample Plan">
                            <p class="title">
                              <?php echo $plan['name']; ?>
                              <span>(#<?php echo $id; ?>)</span>
                              <button type="button" class="notice-dismiss"></button>
                            </p>

                            <input type="hidden" name="subscription_pairs[<?php echo $id; ?>][name]" value="<?php echo $plan['name']; ?>">

                            <div class="options">
                              <?php foreach ($subscribable_plans as $index => $item) : ?>
                                <label>
                                  <input type="radio" name="subscription_pairs[<?php echo $id; ?>][id]" value="<?php echo $item['type'] . '_' . $item['id'] ?>" <?php echo $plan['id'] == ($item['type'] . '_' . $item['id']) ? 'checked' : null ?> />
                                  <span><?php echo $item['type'] ?></span>
                                  <?php echo $item['name'] ?>
                                </label>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        <?php endforeach; ?>
                      </div>
                    </div>

                    <?php if (count($subscribable_plans) > 0 && count($subscription_pairs) > 0 && method_exists($utils::$membership_plugin, 'installation_note')) : ?>
                      <div class="card sc-card sc-card-success">
                        <?php echo $utils::$membership_plugin->installation_note(); ?>
                      </div>
                    <?php else : ?>
                      <div class="card sc-card sc-card-warning">
                        <p>You need to choose a membership plan and pair it with a channel or network before your subscriptions will be sent to Supercast.</p>
                      </div>
                    <?php endif; ?>

                    <p class="description">
                      <?php if (method_exists($utils::$membership_plugin, 'export_note')) : ?>
                        <?php echo $utils::$membership_plugin->export_note(); ?>
                      <?php else : ?>
                        Already have customers? Head over to the <a href="admin.php?page=supercast-export">Exporter page</a> to start creating new customers en masse.
                      <?php endif; ?>
                    </p>
                  </fieldset>
                </td>
              </tr>
            <?php endif; ?>

            <tr>
              <th scope="row">
                <label for="feed_link_providers">Deep links</label>
              </th>
              <td>
                <fieldset class="card sc-card">
                  <input type="hidden" name="feed_link_providers[]" value="" />

                  <div class="link-provider-options">
                    <?php $image_base_path = plugin_dir_url(__FILE__) . '../../assets/deeplink-images/'; ?>

                    <?php foreach ($utils::FEED_LINK_PROVIDERS as $name => $url) : ?>
                      <fieldset>
                        <label>
                          <?php
                            $id = str_replace(' ', '-', strtolower($name));
                            $image_regular_path = $image_base_path . $id . '.png';
                            $image_retina_path = $image_base_path . $id . '.png';
                          ?>

                          <input
                            name="feed_link_providers[]"
                            type="checkbox"
                            value="<?php echo $name ?>"
                            <?php echo (!empty($feed_link_providers) && in_array($name, $feed_link_providers)) ? 'checked' : null ?>
                          />
                          <?php echo "<img src='$image_regular_path' srcset='$image_regular_path 1x, $image_retina_path 2x' alt='$name' />" ?>
                          <?php echo $name ?>
                        </label>
                      </fieldset>
                    <?php endforeach; ?>
                  </div>

                  <p class="description">Check any services you’d like to provide deep links for. When opened on mobile, deep links directly open the desired app.</p>
                  <hr />

                  <label class="provider-icon-label">
                    <input type="hidden" name="display_provider_icons" value="0" />
                    <input type="checkbox" name="display_provider_icons" value="1" <?php echo $utils::is_true($display_provider_icons) ? 'checked' : ''; ?> />
                    <span>Display icons next to service deep links?</span>
                  </label>
                </fieldset>
              </td>
            </tr>
          </tbody>
        </table>

        <p class="actions-area">
          <input type="submit" name="commit" class="button button-primary" value="Save Changes">
        </p>
      </div>

      <div class="right-panel">
        <div class="card">
          <h2>Shortcodes</h2>

          <p>Use these shortcodes to show feeds to your Supercast subscribers. Note that these should be restricted via your membership plugin so that only logged-in users can see them.</p>

          <div class="toggle-section">
            <div class="toggle-header">
              <h3><code>[supercast-feeds]</code></h3>
            </div>

            <div class="toggle-content">
              <p>Use this to output the current user's unique Supercast feed URLs and deep links for any of the services selected in the "Deep links" option.</p>
              <p>Customize the output with the following shortcode attributes:</p>
              <ul>
                <li><code>channel</code> - By default we'll output <i>all</i> channels that are available to the current user. Set to a specific subdomain to render just that channel’s feed. Note the user must have the specified subscription, or nothing will render.</li>
                <li><code>legacy</code> - If set to 'true', we'll use an older native version of shortcodes. Not recommended for most users.</li>
                <li><code>titles (legacy only)</code> - Set to <code>false</code> to disable rendering of each Channel’s title.</li>
                <li><code>type (legacy only)</code> - By default each feed will show both the URL and deep links (<code>all</code>). Set to <code>urls</code> to only render feed URL(s), or <code>deeplinks</code> to only render deep links.</li>
              </ul>
            </div>
          </div>

          <div class="toggle-section">
            <div class="toggle-header">
              <h3><code>[supercast-sms channel=yourchannel]</code></h3>
            </div>

            <div class="toggle-content">
              <p>Use this to output a field for a user to enter their phone number and receive an SMS to log in.</p>
              <p>Customize the output with the following shortcode attributes:</p>
              <ul>
                <li><code>channel</code> - <b>Required.</b> Set to a specific subdomain so we know which Channel to generate the login link for. Note the user must have a subscription to this Channel, or nothing will render.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section data-tab="ama" class="tab-content content-split wrap">
      <div>
        <p><b>Important</b>: your Channel must have AMA enabled on Supercast in order to render the following shortcodes.</p>

        <div class="card">
          <h2>Shortcodes</h2>

          <div class="toggle-section active">
            <div class="toggle-header">
              <h3><code>[supercast-ama-questions channel=yourchannel]</code></h3>
            </div>

            <div class="toggle-content">
              <p>Use this to output a Channel’s AMA questions.</p>
              <p>Customize the output with the following shortcode attributes:</p>
              <ul>
                <li><code>channel</code> - <b>Required.</b> Set to a specific subdomain so we know which Channel’s AMA questions to look for.</li>
              </ul>
            </div>
          </div>

          <div class="toggle-section">
            <div class="toggle-header">
              <h3><code>[supercast-ama-ask channel=yourchannel]</code></h3>
            </div>

            <div class="toggle-content">
              <p>Use this to output fields to ask an AMA question.</p>
              <p>Customize the output with the following shortcode attributes:</p>
              <ul>
                <li><code>channel</code> - <b>Required.</b> Set to a specific subdomain so we know which Channel to ask the question on.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div class="right-panel"></div>
    </section>

    <section data-tab="advanced" class="tab-content wrap">
      <div>
        <table class="form-table">
          <tbody>
            <tr>
              <th scope="row">
                <label for="shortcode_css">Shortcode CSS</label>
              </th>
              <td>
                <fieldset>
                  <div class="code-wrapper">
                    <textarea class="shortcode-css-input" name="shortcode_css" id="shortcode_css"><?php echo stripslashes($shortcode_css); ?></textarea>
                    <p class="description">Customize or delete this CSS to suit your site’s style when rendering short codes or AMA content.</p>
                  </div>
                </fieldset>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="content-split">
          <div>
            <table class="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label>Reset plugin</label>
                  </th>
                  <td>
                    <fieldset>
                      <p>Use the button below to reset your Supercast plugin settings. Note this only resets the plugin and does not impact your Supercast account or configuration.</p>
                      <p><input type="button" class="reset-button button button-secondary" value="Reset plugin" /></p>
                    </fieldset>
                  </td>
                </tr>

                <tr>
                  <th scope="row">
                    <label>Info</label>
                  </th>
                  <td>
                    <fieldset>
                      <p>You're using Supercast for Wordpress v<?php echo $utils::VERSION; ?></p>
                      <p><a href="https://supercast.com" target="_blank">Supercast.com</a></p>
                    </fieldset>
                  </td>
                </tr>
              </tbody>
            </table>

            <p class="actions-area">
              <input type="submit" name="commit" class="button button-primary" value="Save Changes">
            </p>
          </div>

          <div class="right-panel"></div>
        </div>
      </div>

      <div class="right-panel"></div>
    </section>
  </form>
</main>

<form class="reset-form" method="post" action="admin.php?page=supercast" novalidate="novalidate">
  <input type="hidden" name="page" value="supercast-options">
  <input type="hidden" name="action" value="reset">
  <?php wp_nonce_field($utils::IDENTIFIER); ?>
</form>
