<style type="text/css">
  <?php echo $css; ?>
</style>
