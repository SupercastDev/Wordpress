<script src="https://app.supercast.com/js/embed.js"></script>

<? foreach ($subscriptions as $index => $subscription) :
  $subdomain = $subscription['subdomain'];
  ?>

  <supercast-player-links subdomain="<?php echo $subdomain ?>" subscription-identifier="<?php echo $identifier ?>" />

<? endforeach; ?>
