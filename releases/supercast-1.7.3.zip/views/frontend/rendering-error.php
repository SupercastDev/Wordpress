<p class="supercast-render-error">
  <?php echo $message; ?>
</p>
