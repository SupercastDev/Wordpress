<?php

if (!defined('ABSPATH')) { die('Access denied'); }

require_once(SUPERCAST_PLUGIN_DIR . 'lib/membership-plugins/base.php');

use Supercast_Utilities as Utils;
use Supercast_MembershipPlugin_Base as Base;

class Supercast_MembershipPlugin_Memberful extends Base {
  /**
   * Initializes the Memberful membership plugin
   */
  public static function init() {
    Utils::use_membership_plugin(new self([
      'name' => 'Memberful',
      'webhook_endpoint' => 'word_press/memberful',
      'website_url' => 'https://memberful.com/',
      'support_url' => 'https://memberful.com/help/',
    ]));

    parent::init();
  }

  /**
   * Return all Memberful products as an id/title array
   */
  public function feed_access_items() {
    $subscriptions = get_option('memberful_subscriptions', array());

    return array_map(function($subscription) {
      return [
        'id' => $subscription['id'],
        'title' => $subscription['name']
      ];
    }, $subscriptions);
  }

  /**
   * Return all selected Memberful products as an id/title array
   */
  public function selected_feed_access_items() {
    $access_ids = array_filter(Utils::get_option('feed_access_ids'));
    $subscriptions = get_option('memberful_subscriptions', array());
    $access_products = [];

    foreach ($subscriptions as $item) {
      if (in_array($item['id'], $access_ids)) {
        array_push($access_products, [
          'id' => $item['id'],
          'title' => $item['name']
        ]);
      }
    }

    return $access_products;
  }

  /**
   * Print additional notes for installation instructions
   */
  public function installation_note() {
    $access_token = Utils::get_option('access_token');
    $subscription_pairs = array_filter(Utils::get_option('subscription_pairs'));
    $subscribable_plans = array_filter(Utils::get_option('subscribable_plans'));

    $pair_outputs = [];
    $pairing_prefixes = [
      'channel' => 'c',
      'network' => 'n',
    ];

    foreach ($subscription_pairs as $provider_id => $pairing) {
      $output = $provider_id;

      $paired_plan = array_filter($subscribable_plans, function($plan) use($pairing) {
        # Example pair id: 'network_12'
        return sprintf("%s_%d", $plan['type'], $plan['id']) == $pairing['id'];
      });

      if (!empty($paired_plan)) {
        $plan = array_values($paired_plan)[0];
        $output .= ':' . $pairing_prefixes[$plan['type']] . $plan['id'];

        array_push($pair_outputs, $output);
      }
    }

    if (count($pair_outputs) == 0) : ?>
      <div class="installation-note">
        <p class="title">Installation note</p>
        <p>Please pair at least one plan and save your changes to finish Memberful setup.</p>
      </div>
    <?php else : ?>
      <div class="installation-note">
        <p class="title">Installation note</p>
        <p>To connect Memberful to Supercast you'll need to set up a Webhook.</p>
        <p>Head over to your <a href="https://signin.memberful.com/callback" target="_blank">Memberful</a> settings, navigate to <i>Integrate</i> &rarr; <i>Webhooks</i> &rarr; <i>Add a new webhook</i> and create a new webhook for the following URL:</p>
        <p class="memberful-url"><code><?php echo Utils::root_url() . '/webhooks/' . Utils::$membership_plugin->webhook_endpoint . '/events?access_token=' . $access_token . '&list_pairs=' . is_array($pair_outputs) ? join($pair_outputs, ',') : $pair_outputs; ?></code></p>
      </div>
    <?php endif;
  }

  /**
   * Check if the user locally has access to a feed
   */
  public function user_can_access($user) {
    return true;
    // $access_ids = array_filter(Utils::get_option('feed_access_ids'));
    // return memberful_wp_user_has_subscription_to_plans($user->ID, $access_ids);
  }

  /**
   * Print additional notes for export instructions
   */
  public function export_note() {
    ?>
      Already have customers? Head over to your Memberful
      <a href="https://memberful.com/help/general/memberful-dashboard/#members-tab">members page to export them</a>,
      and then import them on the Supercast subscriber import page in your dashboard.
    <?php
  }

  /**
   * Sets up the data we want to deliver as a payload to Supercast
   */
  public static function payload_data($event_name, $args = []) {
    $data = [
      'timestamp' => current_time('timestamp')
    ];

    if ($event_name === 'uninstalled') {
      $data['event_name'] = 'uninstalled';
    }

    return array_filter($data);
  }

  /**
   * Checks if the payload should actually be delivered
   */
  public static function should_deliver_payload() {
    return true;
  }
}
