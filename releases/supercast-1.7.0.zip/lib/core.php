<?php

if (!defined('ABSPATH')) { die('Access denied'); }

use Supercast_API as API;
use Supercast_Utilities as Utils;

class Supercast_Core {
  private static $initialized = false;

  private const L10N_OBJECT = 'Supercastl10n';

  private const SHORTCODE_FEEDS = 'supercast-feeds';
  private const SHORTCODE_SMS = 'supercast-sms';
  private const SHORTCODE_AMA_QUESTIONS = 'supercast-ama-questions';
  private const SHORTCODE_AMA_ASK = 'supercast-ama-ask';

  /**
   * Called when plugin is activated
   */
  public static function activation() {
    Utils::flush();
  }

  /**
   * Called when plugin is deactivated
   */
  public static function deactivation() {
    $access_token = Utils::get_option('access_token');

    if (isset(Utils::$membership_plugin) && !empty($access_token)) {
      $data = Utils::$membership_plugin::payload_data('uninstalled');
      Utils::$membership_plugin::deliver_payload($data, $access_token);
    }

    // Disabling this for now.
    // Utils::reset_options();

    Utils::flush();
  }

  /**
   * Initialize the plugin, get everything bumpin'
   */
  public static function init() {
    if (self::$initialized) {
      return;
    }

    self::$initialized = true;

    add_shortcode(self::SHORTCODE_FEEDS, ['Supercast_Core', 'render_feeds_shortcode']);
    add_shortcode(self::SHORTCODE_SMS, ['Supercast_Core', 'render_sms_shortcode']);
    add_shortcode(self::SHORTCODE_AMA_QUESTIONS, ['Supercast_Core', 'render_questions_shortcode']);
    add_shortcode(self::SHORTCODE_AMA_ASK, ['Supercast_Core', 'render_ask_question_shortcode']);

    add_action('rest_api_init', ['Supercast_Core', 'setup_js_endpoints']);
    add_action('wp_enqueue_scripts', ['Supercast_Core', 'setup_shortcode_js']);
    add_action('wp_print_styles', ['Supercast_Core', 'render_shortcode_custom_css']);
  }

  /**
   * Common method to retrieve template/view code
   */
  public static function get_view($named, $variables = []) {
    extract($variables);
    ob_start();
    include(dirname(__FILE__) . "/../views/frontend/$named.php");
    return ob_get_clean();
  }

  /**
   * Common method to execute shortcodes
   */
  public static function perform_authed_shortcode($named, $args = [], $atts = [], $tag, $success, $fail = null) {
    $options = shortcode_atts($args, array_change_key_case((array)$atts, CASE_LOWER), $tag);
    $user = Utils::current_user();

    if (empty(Utils::get_option('access_token'))) {
      $message = "Erroring rendering shortcode <code>[$named]</code>: please re-connect to Supercast with your access token.";
      return self::get_view('rendering-error', ['message' => $message]);
    }

    $supercast_user = self::get_supercast_user($user);

    if (empty($supercast_user)) {
      $message = stripslashes(Utils::get_option('account_access_error'));
      $default = self::get_view('rendering-error', ['message' => $message]);

      return (!empty($fail) ? $fail($options, $default) : $default);
    }

    return $success($options, $supercast_user);
  }

  /**
   * Renders the shortcode content for the Feed URL
   */
  public static function render_feeds_shortcode($atts = [], $content = null, $tag = '') {
    return self::perform_authed_shortcode(self::SHORTCODE_FEEDS, ['type' => null, 'titles' => null, 'channel' => null], $atts, $tag, function($options, $supercast_user) {
      if (!empty($options['newfeeds'])) {
        return render_js_feeds_shortcode($options, $supercast_user);
      } else {
        $channel = $options['channel'];
        $subscriptions = $supercast_user['subscriptions'];
        $supercast_logo_path = plugin_dir_url(__FILE__) . '../assets/supercast_logo.svg';

        if ($channel != null) {
          $subscriptions = array_filter($supercast_user['subscriptions'], function($subscription) use($channel) {
            return $subscription['subdomain'] == $channel;
          });
        }

        if (count($subscriptions) == 0) { return ''; }

        $link_providers = array_filter(Utils::get_option('feed_link_providers'));
        $display_icons = Utils::is_true(Utils::get_option('display_provider_icons'));
        $image_base_path = plugin_dir_url(__FILE__) . '../assets/deeplink-images/';

        return self::get_view('user-feeds', [
          'subscriptions' => $subscriptions,
          'options' => $options,
          'link_providers' => $link_providers,
          'display_icons' => $display_icons,
          'image_base_path' => $image_base_path,
          'supercast_logo_path' => $supercast_logo_path
        ]);
      }
    });
  }

  /**
   * Renders the shortcode content as a JS embed
   */
  public static function render_js_feeds_shortcode($options, $supercast_user) {
    $channel = $options['channel'];
    $customer_id = $supercast_user['customer_id'];

    if (empty($customer_id)) { return ''; }

    return self::get_view('user-js-feeds', [
      'customer_id' => $customer_id,
      'subdomain' => $channel
    ]);
  }

  /**
   * Renders the shortcode content for sending SMS login links
   */
  public static function render_sms_shortcode($atts = [], $content = null, $tag = '') {
    return self::perform_authed_shortcode(self::SHORTCODE_SMS, [], $atts, $tag, function($options, $supercast_user) {
      $user = Utils::current_user();
      return self::get_view('sms-form', ['user' => $user]);
    });
  }

  /**
   * Renders the shortcode content for channel AMA questions
   */
  public static function render_questions_shortcode($atts = [], $content = null, $tag = '') {
    $options = shortcode_atts(['channel' => null, 'sections' => 'all'], array_change_key_case((array)$atts, CASE_LOWER), $tag);
    $channel = $options['channel'];
    if ($options['sections'] == 'all') {
      $sections = ['featured', 'answered', 'unanswered', 'popular'];
    } else {
      $sections = explode(',', $options['sections']);
    }
    $user = Utils::current_user();
    $token_type = Utils::get_option('subscribable_type');

    if (empty(Utils::get_option('access_token')) || empty($token_type)) {
      $message = 'Erroring rendering shortcode <code>[' . self::SHORTCODE_AMA_QUESTIONS . ']</code>: please re-connect to Supercast with your access token.';
      return self::get_view('rendering-error', ['message' => $message]);
    }

    if ($token_type == 'network' && empty($channel)) {
      $message = 'Erroring rendering shortcode <code>[' . self::SHORTCODE_AMA_QUESTIONS . ']</code>: a <code>channel</code> is required when using a Network access token.';
      return self::get_view('rendering-error', ['message' => $message]);
    }

    $filters = [];

    if (isset($_GET['query'])) {
      $filters['query'] = wp_strip_all_tags($_GET['query']);
    }

    if (isset($_GET['type'])) {
      $filters['type'] = wp_strip_all_tags($_GET['type']);
    }

    if (isset($_GET['sort'])) {
      $filters['sort'] = wp_strip_all_tags($_GET['sort']);
      $filters['direction'] = 'desc';
    } else {
      $filters['sort'] = (isset($filters['type']) && $filters['type'] == 'responded') ? 'responded_at' : 'created_at';
      $filters['direction'] = 'desc';
    }

    if (isset($_GET['ama_page'])) {
      $filters['page'] = wp_strip_all_tags($_GET['ama_page']);
    }

    $response = API::get_questions($channel, $user, $filters);

    if (!$response['success']) {
      $message = stripslashes(Utils::get_option('general_error'));
      return self::get_view('rendering-error', ['message' => $message]);
    }

    return self::get_view('questions-list', [
      'questions' => $response['data'],
      'hasNext' => ($response['page'] * $response['perpage']) < $response['total'],
      'hasPrev' => $response['page'] > 1,
      'ama_page' => $response['page'],
      'channel' => $options['channel'],
      'user' => $user,
      'filters' => $filters,
      'sections' => $sections
    ]);
  }

  /**
   * Renders the shortcode content for channel AMA question prompt
   */
  public static function render_ask_question_shortcode($atts = [], $content = null, $tag = '') {
    return self::perform_authed_shortcode(self::SHORTCODE_SMS, ['channel' => null], $atts, $tag, function($options, $supercast_user) {
      $user = Utils::current_user();

      if (Utils::get_option('subscribable_type') == 'network' && empty($options['channel'])) {
        $message = 'Erroring rendering shortcode <code>[' . self::SHORTCODE_AMA_ASK .']</code>: a <code>channel</code> is required when using a Network access token.';
        return self::get_view('rendering-error', ['message' => $message]);
      }

      return self::get_view('questions-ask-form', [
        'user' => $user,
        'channel' => $options['channel']
      ]);
    });
  }

  /**
   * Retrieves a user's Supercast account
   */
  public static function get_supercast_user($user) {
    if (Utils::logged_out() || empty($user->user_email)) {
      return null;
    }

    $response = API::get_user($user);

    if (!$response['success'] || empty($response['data'])) {
      return null;
    }

    return $response['data'];
  }

  /**
   * Render the custom CSS for our shortcodes
   */
  public static function render_shortcode_custom_css() {
    global $post;

    $custom_css = stripslashes(Utils::get_option('shortcode_css'));

    // If any shortcode is visible, render all the CSS
    // TODO: improve this only load neccesary CSS for a given shortcode
    $feeds_visible = self::shortcode_used(self::SHORTCODE_FEEDS);
    $sms_visible = self::shortcode_used(self::SHORTCODE_SMS);
    $ama_questions_visible = self::shortcode_used(self::SHORTCODE_AMA_QUESTIONS);
    $ama_prompt_visible = self::shortcode_used(self::SHORTCODE_AMA_ASK);

    if ($feeds_visible || $sms_visible || $ama_questions_visible || $ama_prompt_visible) {
      echo self::get_view('css-tag', ['css' => $custom_css]);
    }

    return;
  }

  /**
   * Enqeue the JS for shortcodes
   * TODO: improve this to load JS when shortcode is used anywhere, not just a post
   */
  public static function setup_shortcode_js() {
    global $post;

    $l10n_data = [
      'nonce' => wp_create_nonce('wp_rest'),
      'site_url' => site_url()
    ];

    wp_register_script(
      self::SHORTCODE_FEEDS . '-lib-clipboard-js',
      plugins_url('../assets/frontend/clipboard.min.js', __FILE__),
      [], '2.0.4', true
    );

    wp_register_script(
      self::SHORTCODE_FEEDS . '-js',
      plugins_url('../assets/frontend/copy-feeds.js', __FILE__),
      [self::SHORTCODE_FEEDS . '-lib-clipboard-js'],
      Utils::VERSION, true
    );

    wp_register_script(
      self::SHORTCODE_SMS . '-js',
      plugins_url('../assets/frontend/sms-delivery.js', __FILE__),
      ['jquery'], Utils::VERSION, true
    );

    wp_register_script(
      self::SHORTCODE_AMA_QUESTIONS . '-js',
      plugins_url('../assets/frontend/list-questions.js', __FILE__),
      ['jquery', self::SHORTCODE_AMA_QUESTIONS . '-player-js'],
      Utils::VERSION, true
    );

    wp_register_style(
      self::SHORTCODE_AMA_QUESTIONS . '-lib-plyr-css',
      plugins_url('../assets/frontend/plyr.min.css', __FILE__),
      [], '3.5.6'
    );

    wp_register_script(
      self::SHORTCODE_AMA_QUESTIONS . '-lib-plyr-js',
      plugins_url('../assets/frontend/plyr.min.js', __FILE__),
      [], '3.5.6', true
    );

    wp_register_script(
      self::SHORTCODE_AMA_QUESTIONS . '-player-js',
      plugins_url('../assets/frontend/question-player.js', __FILE__),
      [self::SHORTCODE_AMA_QUESTIONS . '-lib-plyr-js'],
      Utils::VERSION, true
    );

    wp_register_script(
      self::SHORTCODE_AMA_ASK . '-js',
      plugins_url('../assets/frontend/create-question.js', __FILE__),
      ['jquery'], Utils::VERSION, true
    );

    if (self::shortcode_used(self::SHORTCODE_FEEDS)) {
      wp_enqueue_script(self::SHORTCODE_FEEDS . '-js');
    }

    if (self::shortcode_used(self::SHORTCODE_SMS)) {
      wp_localize_script(self::SHORTCODE_SMS . '-js', self::L10N_OBJECT, $l10n_data);
      wp_enqueue_script(self::SHORTCODE_SMS . '-js');
    }

    if (self::shortcode_used(self::SHORTCODE_AMA_QUESTIONS)) {
      wp_enqueue_style(self::SHORTCODE_AMA_QUESTIONS . '-lib-plyr-css');
      wp_localize_script(self::SHORTCODE_AMA_QUESTIONS . '-js', self::L10N_OBJECT, $l10n_data);
      wp_enqueue_script(self::SHORTCODE_AMA_QUESTIONS . '-js');
    }

    if (self::shortcode_used(self::SHORTCODE_AMA_ASK)) {
      wp_localize_script(self::SHORTCODE_AMA_ASK . '-js', self::L10N_OBJECT, $l10n_data);
      wp_enqueue_script(self::SHORTCODE_AMA_ASK . '-js');
    }
  }

  /**
   * Helper to check if a shortcode is being rendered on the page
   * TODO: Can this be improved to check when a shortcode is used anywhere (like sidebar), not just a post?
   */
  public static function shortcode_used($shortcode_string) {
    global $post;

    return !empty($post) && has_shortcode($post->post_content, $shortcode_string);
  }

  /**
   * Sets up JS endpoints so WP frontend can access it
   */
  public static function setup_js_endpoints() {
    register_rest_route('supercast/v1', 'sms', array(
      'methods' => Utils::HTTP_POST,
      'callback' => ['Supercast_Core', 'send_sms'],
    ));

    register_rest_route('supercast/v1', 'questions', array(
      'methods' => Utils::HTTP_POST,
      'callback' => ['Supercast_Core', 'send_question_new'],
    ));

    register_rest_route('supercast/v1', 'questions/(?<question_id>\d+)', array(
      'methods' => Utils::HTTP_GET,
      'callback' => ['Supercast_Core', 'send_question_get'],
    ));

    register_rest_route('supercast/v1', 'questions/(?<question_id>\d+)', array(
      'methods' => Utils::HTTP_DELETE,
      'callback' => ['Supercast_Core', 'send_question_delete'],
    ));

    register_rest_route('supercast/v1', 'questions/(?<question_id>\d+)/participate', array(
      'methods' => Utils::HTTP_PATCH,
      'callback' => ['Supercast_Core', 'send_question_participate'],
    ));
  }

  /**
   * Sends API request to deliver login SMS
   */
  public static function send_sms($request) {
    $phone_number = $request->get_param('phone_number');
    $user = wp_get_current_user();

    return API::login_sms($user, $phone_number);
  }

  /**
   * Sends API request to create new AMA question
   */
  public static function send_question_new($request) {
    $channel = $request->get_param('channel');
    $title = $request->get_param('title');
    $body = $request->get_param('body');
    $user = wp_get_current_user();

    return API::create_question($user, $channel, $title, $body);
  }

  /**
   * Sends API request to get a question
   */
  public static function send_question_get($request) {
    $question_id = $request->get_param('question_id');
    $channel = $request->get_param('channel');
    $user = wp_get_current_user();

    return API::get_question($user, $channel, $question_id);
  }

  /**
   * Sends API request to delete the current question
   */
  public static function send_question_delete($request) {
    $question_id = $request->get_param('question_id');
    $channel = $request->get_param('channel');
    $user = wp_get_current_user();

    return API::delete_question($user, $channel, $question_id);
  }

  /**
   * Sends API request to toggle AMA question participation
   */
  public static function send_question_participate($request) {
    $question_id = $request->get_param('question_id');
    $channel = $request->get_param('channel');
    $user = wp_get_current_user();

    return API::toggle_question_participation($user, $channel, $question_id);
  }
}
