var Supercast = Supercast || {};
Supercast.Player = {};

Supercast.Player.initialized = false;

Supercast.Player.play = function() {
  if (!Supercast.Player.initialized) {
    throw(new Error('Player not initialized'));
  }

  Supercast.Player.instance.play();
}

Supercast.Player.setAudio = function(data, autoPlay) {
  if (!Supercast.Player.initialized) {
    return Supercast.Player.initialize(data, autoPlay);
  }

  Supercast.Player.instance.source = {
    type: 'audio',
    title: data.title,
    example: 'hey',
    sources: [
      {
        src: data.audio_url
      }
    ]
  };

  if (data.transcript) {
    Supercast.Player.instance.elements.container.querySelector('.track-transcript .inner').innerHTML = '<p>' + data.transcript.replace(/(?:\r\n|\r|\n)/g, '<br>') + '</p>';
    Supercast.Player.instance.elements.container.classList.add('has-transcript', 'transcript-hidden');

    Supercast.Player.instance.elements.container.querySelector('.transcript-toggle').addEventListener('click', function() {
      Supercast.Player.instance.elements.container.classList.toggle('transcript-hidden');
    });
  } else {
    Supercast.Player.instance.elements.container.classList.remove('has-transcript', 'transcript-hidden');
  }

  Supercast.Player.instance.on('loadeddata', function() {
    Supercast.Player.instance.currentTime = data.timestamp;

    if (autoPlay) {
      Supercast.Player.play();
    }
  });
}

Supercast.Player.initialize = function(data, autoPlay) {
  if (Supercast.Player.initialized) {
    return Supercast.Player.setAudio(data);
  }

  var audioEl = document.createElement('audio');
  audioEl.setAttribute('controls', 'controls');
  document.body.appendChild(audioEl);

  Supercast.Player.instance = new Plyr(audioEl, {
    controls: function(args) {
      return `
        <div class="plyr__controls">
          <div class="track-info">
            <h3>Now Playing: <span>{title}</span></h3>
            <button type="button" class="transcript-toggle plyr__control" aria-label="Toggle transcript">
              TRANSCRIPT
            </button>
          </div>

          <div class="track-controls">
            <button type="button" class="plyr__control" aria-label="Play, {title}" data-plyr="play">
              <svg class="icon--pressed" role="presentation"><use xlink:href="#plyr-pause"></use></svg>
              <svg class="icon--not-pressed" role="presentation"><use xlink:href="#plyr-play"></use></svg>
              <span class="label--pressed plyr__tooltip" role="tooltip">Pause</span>
              <span class="label--not-pressed plyr__tooltip" role="tooltip">Play</span>
            </button>

            <div class="plyr__progress">
              <input data-plyr="seek" type="range" min="0" max="100" step="0.01" value="0" aria-label="Seek">
              <progress class="plyr__progress__buffer" min="0" max="100" value="0">% buffered</progress>
              <span role="tooltip" class="plyr__tooltip">00:00</span>
            </div>

            <div class="plyr__time plyr__time--current" aria-label="Current time">00:00</div>
            <div class="plyr__time plyr__time--duration" aria-label="Duration">00:00</div>

            <button type="button" class="plyr__control" aria-label="Mute" data-plyr="mute">
              <svg class="icon--pressed" role="presentation"><use xlink:href="#plyr-muted"></use></svg>
              <svg class="icon--not-pressed" role="presentation"><use xlink:href="#plyr-volume"></use></svg>
              <span class="label--pressed plyr__tooltip" role="tooltip">Unmute</span>
              <span class="label--not-pressed plyr__tooltip" role="tooltip">Mute</span>
            </button>

            <div class="plyr__volume">
              <input data-plyr="volume" type="range" min="0" max="1" step="0.05" value="1" autocomplete="off" aria-label="Volume">
            </div>
          </div>

          <div class="track-transcript">
            <div class="inner"></div>
          </div>
        </div>
      `;
    }
  });

  Supercast.Player.instance.on('ready', function() {
    if (!Supercast.Player.initialized) {
      Supercast.Player.initialized = true;
      Supercast.Player.setAudio(data, autoPlay);
    }
  });
}
