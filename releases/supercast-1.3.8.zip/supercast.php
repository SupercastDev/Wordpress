<?php
/*
 * Plugin Name: Supercast
 * Plugin URI: https://supercast.com
 * Description: Connect your Supercast account to WordPress
 * Version: 1.3.8
 * Author: Supercast
 */

if (!defined('ABSPATH')) { die('Access denied'); }

define('SUPERCAST_PLUGIN_DIR', plugin_dir_path(__FILE__));

require_once(SUPERCAST_PLUGIN_DIR . 'lib/core.php');
require_once(SUPERCAST_PLUGIN_DIR . 'lib/utilities.php');
require_once(SUPERCAST_PLUGIN_DIR . 'lib/api.php');

use Supercast_Utilities as Utils;

if (is_admin()) {
  require_once(SUPERCAST_PLUGIN_DIR . 'lib/options.php');
  add_action('init', array('Supercast_Options', 'init'));
}

if (!function_exists('is_plugin_active')) {
  include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

if (is_plugin_active('memberpress/memberpress.php')) {
  require_once(SUPERCAST_PLUGIN_DIR . 'lib/membership-plugins/memberpress.php');
  add_action('init', array('Supercast_MembershipPlugin_MemberPress', 'init'), 5);
}

if (is_plugin_active('memberful-wp/memberful-wp.php')) {
  require_once(SUPERCAST_PLUGIN_DIR . 'lib/membership-plugins/memberful.php');
  add_action('init', array('Supercast_MembershipPlugin_Memberful', 'init'), 5);
}

if (is_plugin_active('woocommerce-subscriptions/woocommerce-subscriptions.php')) {
  require_once(SUPERCAST_PLUGIN_DIR . 'lib/membership-plugins/woo_commerce_subscriptions.php');
  add_action('init', array('Supercast_MembershipPlugin_WooCommerceSubscriptions', 'init'), 5);
}

add_action('init', array('Supercast_Core', 'init'));

register_activation_hook(__FILE__, array('Supercast_Core', 'activation'));
register_deactivation_hook(__FILE__, array('Supercast_Core', 'deactivation'));
