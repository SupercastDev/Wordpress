<?php

if (!defined('ABSPATH')) { die('Access denied'); }

require_once(SUPERCAST_PLUGIN_DIR . 'lib/membership-plugins/base.php');

use Supercast_Utilities as Utils;
use Supercast_MembershipPlugin_Base as Base;

class Supercast_MembershipPlugin_WooCommerceSubscriptions extends Base {
  /**
   * Any event that should trigger a webhook payload
   */
  public const WEBHOOK_EVENTS = [
    'woocommerce_subscription_status_active',
    'woocommerce_subscription_status_cancelled',
    'woocommerce_subscription_status_expired',
    'profile_update'
  ];

  /**
   * Initializes the WooCommerce Subscriptions provider
   */
  public static function init() {
    Utils::use_membership_plugin(new self([
      'name' => 'WooCommerceSubscriptions',
      'webhook_endpoint' => 'word_press/woo_commerce_subscriptions',
      'website_url' => 'https://woocommerce.com/',
      'support_url' => 'https://docs.woocommerce.com/',
    ]));

    parent::init();
  }

  /**
   * Return all WooCommerce products as an id/title array
   */
  public function feed_access_items() {
    $products = array();
    $query = new WC_Product_Query(array(
      'limit' => -1
    ));

    foreach ($query->get_products() as $product) {
      $products[] = [
        'id' => $product->get_id(),
        'title' => $product->get_name()
      ];

      foreach ($product->get_children() as $id) {
        $child = wc_get_product( $id );
        $products[] = [
          'id' => $child->get_id(),
          'title' => '&nbsp;-&nbsp;' . $child->get_name()
        ];
      }
    }
    return $products;
  }

  /**
   * Print additional notes for installation instructions
   */
  public function installation_note() { ?>
    <p>You're all set. Changes to your WooCommerce subscriptions above will be automatically sent to Supercast.</p>
  <?php }

  /**
   * Creates a CSV of active subscription holders
   */
  public static function export_subscribers($list_ids_to_use) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=woo_customer_export_for_supercast-' . date("Y-m-d") . '.csv');

    $output = fopen('php://output', 'w');

    fputcsv($output, [
      'Email',
      'First Name',
      'Last Name',
      'Created At'
    ]);

    # Only export active subscriptions to avoid status mismatch between Woo / Supercast
    $subscriptions = wcs_get_subscriptions_for_product($list_ids_to_use, 'subscription', ['subscription_status' => 'active']);

    foreach ( $subscriptions as $subscription ) {
      $user_id = $subscription->get_user_id();

      $row = [
        Utils::get_user($args[0])->user_email,
        Utils::get_user($args[0])->first_name,
        Utils::get_user($args[0])->last_name,
        $subscription->get_date_created()
      ];
      fputcsv($output, $row);
    }

    fclose($output);
    exit;
  }

  /**
   * Sets up the data we want to deliver as a payload to Supercast
   */
  public static function payload_data($event_name, $args = []) {
    $data = [
      'timestamp' => current_time('timestamp')
    ];

    if ($event_name === 'uninstalled') {
      $data['event_name'] = 'uninstalled';

    } elseif ($event_name === 'profile_update') {
      $data['event_name'] = 'profile_update';
      $data['user'] = [
        'email' => $args[1]->user_email,
        'data' => [
          'email' => Utils::get_user($args[0])->user_email,
          'first_name' => Utils::get_user($args[0])->first_name,
          'last_name' => Utils::get_user($args[0])->last_name,
        ]
      ];

    } else {
      $data['event_name'] = 'woo_commerce_subscriptions_update';
      $subscription = $args[0];

      $user_id = $subscription->get_user_id();
      $data['user'] = [
        'id'                => $user_id,
        'email'             => Utils::get_user($user_id)->user_email,
        'first_name'        => Utils::get_user($user_id)->first_name,
        'last_name'         => Utils::get_user($user_id)->last_name
      ];

      if (count($subscription->get_items()) > 0) {
        $data['subscription'] = [
          'id'          => $subscription->get_id(),
          'product_id'  => array_values( $subscription->get_items() )[0]->get_product_id(),
          'number'      => $subscription->get_order_key(),
          'active'      => $subscription->get_status() === 'active' ? true : false,
          'gateway'     => $subscription->get_payment_method_to_display(),
          'created_at'  => $subscription->get_date( 'start_date' )
        ];
      }
    }

    $subscription_pairs = array_filter(Utils::get_option('subscription_pairs'));
    $subscribable_plans = array_filter(Utils::get_option('subscribable_plans'));

    $product_id = $data['subscription']['product_id'];
    $pair = $subscription_pairs[$product_id];

    if ($pair) {
      $paired_plan = array_filter($subscribable_plans, function($plan) use($pair) {
        # Example pair id: 'network_12'
        return sprintf("%s_%d", $plan['type'], $plan['id']) == $pair['id'];
      });

      if (!empty($paired_plan)) {
        $plan = array_values($paired_plan)[0];

        if ($plan['type'] == 'channel') {
          $data['channel_subdomain'] = $plan['subdomain'];
        } else if ($plan['type'] == 'network') {
          $data['bundle_id'] = intval($plan['id']);
        }
      }
    }

    return array_filter($data);
  }

  /**
   * Checks if the payload should actually be delivered
   */
  public static function should_deliver_payload() {
    return true;
  }
}
