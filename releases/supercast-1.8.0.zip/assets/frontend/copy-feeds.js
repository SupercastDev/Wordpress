var Supercast = Supercast || {};

Supercast.copyFeeds = function() {
  var buttons = document.querySelectorAll('.supercast-feed-url-button');

  if (!buttons.length) { return; }

  [].forEach.call(buttons, function(button) {
    var clipboard = new ClipboardJS(button);

    clipboard.on('success', function(event) {
      event.trigger.innerText = 'Copied!';

      setTimeout(function() {
        event.trigger.innerText = 'Copy';
      }, 1000);
    });
  });
};

Supercast.copyFeeds();
